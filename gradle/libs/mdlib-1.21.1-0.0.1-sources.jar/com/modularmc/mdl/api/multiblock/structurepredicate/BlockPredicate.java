package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternCandidate;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Matches exact block instances.
 */
public record BlockPredicate(List<Block> blocks) implements StructurePredicate {

    public BlockPredicate {
        blocks = List.copyOf(blocks);
        if (blocks.isEmpty()) {
            throw new IllegalArgumentException("Block predicate must contain at least one block");
        }
    }

    public static BlockPredicate fromJson(JsonObject object) {
        return new BlockPredicate(JsonHelpers.oneOrMoreStrings(object, "blocks", "block").stream()
                .map(id -> resolveBlock(JsonHelpers.parseId(id, "block")))
                .toList());
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.BLOCKS;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        boolean matched = blocks.contains(state.getBlockState().getBlock());
        if (!matched) {
            state.setDiagnostic(PatternDiagnostic.of("block_mismatch", "Block predicate did not match",
                    state.getPos(), expected()));
        }
        return matched;
    }

    @Override
    public List<Block> blockCandidates() {
        return blocks;
    }

    @Override
    public List<PatternCandidate> patternCandidates() {
        List<PatternCandidate> candidates = new ArrayList<>();
        for (Block block : blocks) {
            ItemStack stack = block.asItem().getDefaultInstance();
            if (!stack.isEmpty()) {
                candidates.add(new PatternCandidate(block.defaultBlockState(), stack));
            }
        }
        return List.copyOf(candidates);
    }

    @Override
    public boolean hasAir() {
        return blocks.contains(Blocks.AIR);
    }

    private List<String> expected() {
        return blocks.stream().map(block -> BuiltInRegistries.BLOCK.getKey(block).toString()).toList();
    }

    static Block resolveBlock(ResourceLocation id) {
        Block block = BuiltInRegistries.BLOCK.get(id);
        if (block == null || !id.equals(BuiltInRegistries.BLOCK.getKey(block))) {
            throw new IllegalStateException("Unknown block id in structure predicate: " + id);
        }
        return block;
    }
}
