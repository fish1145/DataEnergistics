package com.modularmc.mdl.api.multiblock;

import java.util.ArrayList;
import java.util.List;

/**
 * Immutable structural layout metadata used to validate and expand a block pattern.
 */
public final class PatternLayout {

    private final List<PatternUnit> units;
    private final int width;
    private final int height;
    private final int sourceDepth;
    private final int controllerX;
    private final int controllerY;
    private final int controllerSourceLayer;
    private final int controllerUnitIndex;
    private final int controllerInnerLayer;

    private PatternLayout(List<PatternUnit> units, int width, int height, int sourceDepth,
                          int controllerX, int controllerY, int controllerSourceLayer,
                          int controllerUnitIndex, int controllerInnerLayer) {
        this.units = List.copyOf(units);
        this.width = width;
        this.height = height;
        this.sourceDepth = sourceDepth;
        this.controllerX = controllerX;
        this.controllerY = controllerY;
        this.controllerSourceLayer = controllerSourceLayer;
        this.controllerUnitIndex = controllerUnitIndex;
        this.controllerInnerLayer = controllerInnerLayer;
    }

    /**
     * Derives immutable layout metadata from an existing pattern.
     *
     * @param pattern source pattern
     * @return derived layout
     */
    static PatternLayout from(BlockPattern pattern) {
        CenterOffset controller = pattern.getCenterOffset();
        if (controller.x() < 0 || controller.x() >= pattern.getPalmLength() || controller.y() < 0 ||
                controller.y() >= pattern.getThumbLength()) {
            throw new IllegalArgumentException("Pattern controller x/y coordinate is outside the source dimensions");
        }
        List<PatternUnit> units = new ArrayList<>(pattern.unitCount());
        int expectedStart = 0;
        int controllerUnitIndex = -1;
        int controllerInnerLayer = -1;
        for (int index = 0; index < pattern.unitCount(); index++) {
            int sourceStart = pattern.unitStart(index);
            int depth = pattern.unitDepth(index);
            if (sourceStart != expectedStart) {
                throw new IllegalArgumentException("Pattern units must be contiguous at index " + index);
            }
            RepeatRange repeats = pattern.unitRepeatRange(index);
            PatternUnit unit = new PatternUnit(index, sourceStart, depth, repeats);
            units.add(unit);
            if (controller.z() >= sourceStart && controller.z() < unit.sourceEndExclusive()) {
                if (repeats.min() != 1 || repeats.max() != 1) {
                    throw new IllegalArgumentException(
                            "The pattern unit containing the controller must repeat exactly once");
                }
                controllerUnitIndex = index;
                controllerInnerLayer = controller.z() - sourceStart;
            }
            expectedStart = unit.sourceEndExclusive();
        }
        if (controllerUnitIndex < 0 || expectedStart != pattern.getFingerLength()) {
            throw new IllegalArgumentException("Pattern controller or source depth is outside its unit layout");
        }
        return new PatternLayout(units, pattern.getPalmLength(), pattern.getThumbLength(),
                pattern.getFingerLength(), controller.x(), controller.y(), controller.z(), controllerUnitIndex,
                controllerInnerLayer);
    }

    /** @return immutable units in source order */
    public List<PatternUnit> units() {
        return units;
    }

    /** @return pattern width along the character axis */
    public int width() {
        return width;
    }

    /** @return pattern height along the string axis */
    public int height() {
        return height;
    }

    /** @return number of unexpanded source aisles */
    public int sourceDepth() {
        return sourceDepth;
    }

    /** @return controller coordinate along the character axis */
    public int controllerX() {
        return controllerX;
    }

    /** @return controller coordinate along the string axis */
    public int controllerY() {
        return controllerY;
    }

    /** @return controller source aisle index */
    public int controllerSourceLayer() {
        return controllerSourceLayer;
    }

    /** @return unit containing the controller source aisle */
    public int controllerUnitIndex() {
        return controllerUnitIndex;
    }

    /** @return controller aisle index inside its unit */
    public int controllerInnerLayer() {
        return controllerInnerLayer;
    }
}
