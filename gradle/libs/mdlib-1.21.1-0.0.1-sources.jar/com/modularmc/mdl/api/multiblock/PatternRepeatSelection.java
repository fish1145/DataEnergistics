package com.modularmc.mdl.api.multiblock;

import java.util.ArrayList;
import java.util.List;

/**
 * Immutable repeat count selection aligned with a {@link PatternLayout}.
 */
public final class PatternRepeatSelection {

    private final List<Integer> counts;

    private PatternRepeatSelection(List<Integer> counts) {
        this.counts = List.copyOf(counts);
    }

    /**
     * Creates and validates a selection for a layout.
     *
     * @param layout target layout
     * @param counts one count per unit
     * @return validated immutable selection
     */
    public static PatternRepeatSelection of(PatternLayout layout, List<Integer> counts) {
        if (counts.size() != layout.units().size()) {
            throw new IllegalArgumentException("Expected " + layout.units().size() +
                    " repeat counts, got " + counts.size());
        }
        List<Integer> validated = new ArrayList<>(counts.size());
        for (int index = 0; index < counts.size(); index++) {
            int count = counts.get(index);
            validated.add(layout.units().get(index).repeats().requireValid(count));
        }
        return new PatternRepeatSelection(validated);
    }

    /**
     * Uses every unit's minimum repeat count.
     *
     * @param layout target layout
     * @return minimum selection
     */
    public static PatternRepeatSelection minimum(PatternLayout layout) {
        return of(layout, layout.units().stream().map(unit -> unit.repeats().min()).toList());
    }

    /**
     * Uses every unit's maximum repeat count.
     *
     * @param layout target layout
     * @return maximum selection
     */
    public static PatternRepeatSelection maximum(PatternLayout layout) {
        return of(layout, layout.units().stream().map(unit -> unit.repeats().max()).toList());
    }

    /**
     * @param unitIndex target unit index
     * @return selected count
     */
    public int count(int unitIndex) {
        return counts.get(unitIndex);
    }

    /** @return immutable counts in unit order */
    public List<Integer> counts() {
        return counts;
    }
}
