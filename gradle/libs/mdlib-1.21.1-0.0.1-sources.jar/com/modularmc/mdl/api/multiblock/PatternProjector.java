package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Expands repeatable source aisles into immutable, controller-relative cells.
 */
public final class PatternProjector {

    /** Default cell budget that prevents malformed repeat selections from exhausting client memory. */
    public static final int DEFAULT_MAX_EXPANDED_CELLS = BlockPattern.MAX_PATTERN_CELLS;

    private PatternProjector() {}

    /**
     * Expands a pattern using the canonical north-facing orientation.
     *
     * @param pattern   source pattern
     * @param selection validated repeat selection
     * @return immutable expanded snapshot
     */
    public static ExpandedPatternSnapshot expand(BlockPattern pattern, PatternRepeatSelection selection) {
        return expand(pattern, selection, Direction.NORTH, Direction.NORTH, false, DEFAULT_MAX_EXPANDED_CELLS);
    }

    /**
     * Expands a pattern using a controller orientation.
     *
     * @param pattern       source pattern
     * @param selection     validated repeat selection
     * @param frontFacing   controller front
     * @param upwardsFacing controller upwards orientation
     * @param flipped       whether the pattern is mirrored
     * @return immutable expanded snapshot
     */
    public static ExpandedPatternSnapshot expand(BlockPattern pattern, PatternRepeatSelection selection,
                                                 Direction frontFacing, Direction upwardsFacing, boolean flipped) {
        return expand(pattern, selection, frontFacing, upwardsFacing, flipped, DEFAULT_MAX_EXPANDED_CELLS);
    }

    /**
     * Expands a pattern while enforcing a caller-selected materialization budget.
     *
     * @param pattern       source pattern
     * @param selection     validated repeat selection
     * @param frontFacing   controller front
     * @param upwardsFacing controller upwards orientation
     * @param flipped       whether the pattern is mirrored
     * @param maxCells      maximum number of cells allowed in the returned snapshot
     * @return immutable expanded snapshot
     */
    public static ExpandedPatternSnapshot expand(BlockPattern pattern, PatternRepeatSelection selection,
                                                 Direction frontFacing, Direction upwardsFacing, boolean flipped,
                                                 int maxCells) {
        PatternLayout layout = pattern.getLayout();
        PatternRepeatSelection validated = PatternRepeatSelection.of(layout, selection.counts());
        ProjectionSize projectionSize = projectionSize(layout, validated, maxCells);

        int controllerExpandedLayer = expandedControllerLayer(layout, validated);
        List<PatternLayerSnapshot> layers = new ArrayList<>(projectionSize.layers());
        List<PatternCellSnapshot> cells = new ArrayList<>(projectionSize.cells());
        int cellsPerLayer = Math.multiplyExact(layout.width(), layout.height());
        int expandedLayer = 0;
        for (PatternUnit unit : layout.units()) {
            for (int repeat = 0; repeat < validated.count(unit.index()); repeat++) {
                for (int inner = 0; inner < unit.depth(); inner++) {
                    int sourceLayer = unit.sourceStart() + inner;
                    List<PatternCellSnapshot> layerCells = new ArrayList<>(cellsPerLayer);
                    for (int y = 0; y < layout.height(); y++) {
                        for (int x = 0; x < layout.width(); x++) {
                            BlockPos relativePosition = pattern.getActualRelativeOffset(
                                    x - layout.controllerX(), y - layout.controllerY(),
                                    expandedLayer - controllerExpandedLayer, frontFacing, upwardsFacing, flipped);
                            PatternCellSnapshot cell = new PatternCellSnapshot(relativePosition,
                                    new PatternCellSource(unit.index(), repeat, sourceLayer, x, y),
                                    pattern.getPredicate(sourceLayer, y, x));
                            layerCells.add(cell);
                            cells.add(cell);
                        }
                    }
                    layers.add(new PatternLayerSnapshot(expandedLayer,
                            new PatternLayerSource(unit.index(), repeat, inner, sourceLayer), layerCells));
                    expandedLayer++;
                }
            }
        }
        return new ExpandedPatternSnapshot(validated, layers, cells, bounds(cells));
    }

    private static ProjectionSize projectionSize(PatternLayout layout, PatternRepeatSelection selection,
                                                 int maxCells) {
        if (maxCells <= 0) {
            throw new IllegalArgumentException("Maximum expanded cell count must be positive");
        }
        long layerCount = 0;
        for (PatternUnit unit : layout.units()) {
            long unitLayers = Math.multiplyExact((long) unit.depth(), selection.count(unit.index()));
            layerCount = Math.addExact(layerCount, unitLayers);
        }
        long cellsPerLayer = Math.multiplyExact((long) layout.width(), layout.height());
        long cellCount = Math.multiplyExact(layerCount, cellsPerLayer);
        if (layerCount > Integer.MAX_VALUE) {
            throw new IllegalArgumentException(
                    "Expanded layer count exceeds the supported integer range: " + layerCount);
        }
        if (cellCount > maxCells) {
            throw new IllegalArgumentException("Expanded cell count " + cellCount + " exceeds limit " + maxCells);
        }
        return new ProjectionSize((int) layerCount, (int) cellCount);
    }

    private static int expandedControllerLayer(PatternLayout layout, PatternRepeatSelection selection) {
        int layer = 0;
        for (PatternUnit unit : layout.units()) {
            if (unit.index() == layout.controllerUnitIndex()) {
                return layer + layout.controllerInnerLayer();
            }
            layer = Math.addExact(layer, Math.multiplyExact(unit.depth(), selection.count(unit.index())));
        }
        throw new IllegalStateException("Controller unit disappeared from the validated layout");
    }

    private static PatternBounds bounds(List<PatternCellSnapshot> cells) {
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;
        for (PatternCellSnapshot cell : cells) {
            BlockPos position = cell.relativePosition();
            minX = Math.min(minX, position.getX());
            minY = Math.min(minY, position.getY());
            minZ = Math.min(minZ, position.getZ());
            maxX = Math.max(maxX, position.getX());
            maxY = Math.max(maxY, position.getY());
            maxZ = Math.max(maxZ, position.getZ());
        }
        return new PatternBounds(new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ));
    }

    private record ProjectionSize(int layers, int cells) {}
}
