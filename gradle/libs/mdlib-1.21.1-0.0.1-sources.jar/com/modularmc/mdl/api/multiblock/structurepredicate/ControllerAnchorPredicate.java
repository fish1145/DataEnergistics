package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.MDLib;
import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.resources.ResourceLocation;

import java.util.List;

/**
 * Neutral anchor predicate for the multiblock controller position.
 * <p>
 * This predicate exists so GregTech-style {@code '~'} symbols can mark the
 * controller anchor without implying any block type or block-state candidate.
 */
public enum ControllerAnchorPredicate implements StructurePredicate {

    INSTANCE;

    @Override
    public ResourceLocation type() {
        return MDLib.id("controller_anchor");
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        boolean matched = state.getPos().equals(state.getControllerPos());
        if (!matched) {
            state.setDiagnostic(PatternDiagnostic.of("controller_anchor_mismatch",
                    "Controller anchor must match the controller position", state.getPos(), List.of()));
        }
        return matched;
    }
}
