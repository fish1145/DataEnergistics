package com.modularmc.mdl.api.multiblock;

/**
 * Immutable legal repeat range for one pattern unit.
 *
 * @param min minimum accepted repeat count
 * @param max maximum accepted repeat count
 */
public record RepeatRange(int min, int max) {

    public RepeatRange {
        if (min <= 0 || max < min) {
            throw new IllegalArgumentException("Repeat range must be positive and min <= max: " + min + ".." + max);
        }
    }

    /**
     * Validates one selected repeat count.
     *
     * @param count selected count
     * @return the validated count
     */
    public int requireValid(int count) {
        if (count < min || count > max) {
            throw new IllegalArgumentException("Repeat count " + count + " outside [" + min + ", " + max + "]");
        }
        return count;
    }
}
