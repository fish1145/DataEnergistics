package com.modularmc.mdl.api.multiblock;

import java.util.function.Predicate;

/**
 * Optional whole-pattern condition evaluated after spatial matching succeeds.
 */
public record PatternCondition(Predicate<MultiblockState> condition, String translationKey) {

    public PatternCondition {
        if (condition == null) {
            throw new IllegalArgumentException("Pattern condition cannot be null");
        }
        if (translationKey == null || translationKey.isBlank()) {
            throw new IllegalArgumentException("Pattern condition translation key cannot be blank");
        }
    }
}
