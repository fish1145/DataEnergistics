package com.modularmc.mdl.api.multiblock;

/**
 * Source coordinates retained for one expanded pattern cell.
 *
 * @param unitIndex   source unit index
 * @param repeatIndex repetition inside the unit
 * @param sourceLayer unexpanded source aisle index
 * @param x           character-axis index
 * @param y           string-axis index
 */
public record PatternCellSource(int unitIndex, int repeatIndex, int sourceLayer, int x, int y) {

    public PatternCellSource {
        if (unitIndex < 0 || repeatIndex < 0 || sourceLayer < 0 || x < 0 || y < 0) {
            throw new IllegalArgumentException("Pattern cell source coordinates cannot be negative");
        }
    }
}
