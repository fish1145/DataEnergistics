package com.modularmc.mdl.api.multiblock;

import it.unimi.dsi.fastutil.longs.Long2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Mutable metadata bag populated while checking a structure.
 */
public final class PatternMatchContext {

    private final Map<String, Object> data;

    public PatternMatchContext() {
        this.data = new HashMap<>();
    }

    private PatternMatchContext(Map<String, Object> data) {
        this.data = new HashMap<>(data);
    }

    public void reset() {
        data.clear();
    }

    public boolean contains(String key) {
        return data.containsKey(key);
    }

    public <T> void put(String key, T value) {
        data.put(requireKey(key), Objects.requireNonNull(value, "value"));
    }

    public <T> T get(String key, Class<T> type) {
        Object value = data.get(requireKey(key));
        return value == null ? null : type.cast(value);
    }

    public <T> T getOrDefault(String key, Class<T> type, T fallback) {
        T value = get(key, type);
        return value == null ? fallback : value;
    }

    public <T> T getOrCreate(String key, Class<T> type, Supplier<? extends T> supplier) {
        Object value = data.computeIfAbsent(requireKey(key), unused -> Objects.requireNonNull(supplier.get(),
                "Pattern match context supplier returned null"));
        return type.cast(value);
    }

    public Map<String, Object> asMap() {
        return Map.copyOf(data);
    }

    public PatternMatchContext copy() {
        return new PatternMatchContext(data);
    }

    Snapshot snapshot() {
        return new Snapshot(copyData(data));
    }

    void restore(Snapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        data.clear();
        data.putAll(copyData(snapshot.data));
    }

    private static String requireKey(String key) {
        if (key == null || key.isBlank()) {
            throw new IllegalArgumentException("Pattern match context key cannot be blank");
        }
        return key;
    }

    private static Map<String, Object> copyData(Map<String, Object> source) {
        Map<String, Object> copy = new HashMap<>();
        source.forEach((key, value) -> copy.put(key, copyValue(key, value)));
        return copy;
    }

    private static Object copyValue(String path, Object value) {
        if (value instanceof String || isImmutableNumber(value) || value instanceof Boolean ||
                value instanceof Character || value instanceof Enum<?>) {
            return value;
        }
        if (value instanceof Long2ObjectMap<?> map) {
            Long2ObjectArrayMap<Object> copy = new Long2ObjectArrayMap<>();
            for (Long2ObjectMap.Entry<?> entry : map.long2ObjectEntrySet()) {
                copy.put(entry.getLongKey(), copyValue(path + "[" + entry.getLongKey() + "]", entry.getValue()));
            }
            return copy;
        }
        if (value instanceof Map<?, ?> map) {
            Map<Object, Object> copy = new HashMap<>();
            map.forEach((key, entryValue) -> copy.put(copyValue(path + ".key", key),
                    copyValue(path + "[" + key + "]", entryValue)));
            return copy;
        }
        if (value instanceof Set<?> set) {
            Set<Object> copy = new HashSet<>();
            set.forEach(entry -> copy.add(copyValue(path + "[]", entry)));
            return copy;
        }
        if (value instanceof List<?> list) {
            List<Object> copy = new ArrayList<>(list.size());
            list.forEach(entry -> copy.add(copyValue(path + "[]", entry)));
            return copy;
        }
        throw new IllegalStateException("Pattern match context value is not rollback-copyable at '" + path +
                "': " + value.getClass().getName());
    }

    private static boolean isImmutableNumber(Object value) {
        return value instanceof Byte || value instanceof Short || value instanceof Integer || value instanceof Long ||
                value instanceof Float || value instanceof Double || value instanceof java.math.BigInteger ||
                value instanceof java.math.BigDecimal;
    }

    record Snapshot(Map<String, Object> data) {}
}
