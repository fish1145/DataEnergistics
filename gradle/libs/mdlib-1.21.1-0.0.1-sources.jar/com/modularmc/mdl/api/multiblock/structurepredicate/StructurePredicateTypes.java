package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.MDLib;

import net.minecraft.resources.ResourceLocation;

import com.google.gson.JsonObject;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

/**
 * Small fail-fast registry for MDL structure predicate JSON types.
 */
public final class StructurePredicateTypes {

    public static final ResourceLocation ANY = MDLib.id("any");
    public static final ResourceLocation AIR = MDLib.id("air");
    public static final ResourceLocation BLOCKS = MDLib.id("blocks");
    public static final ResourceLocation BLOCK_STATES = MDLib.id("block_states");
    public static final ResourceLocation BLOCK_TAGS = MDLib.id("block_tags");
    public static final ResourceLocation FLUIDS = MDLib.id("fluids");
    public static final ResourceLocation FLUID_TAGS = MDLib.id("fluid_tags");
    public static final ResourceLocation RESTRICTED = MDLib.id("restricted");
    public static final ResourceLocation CONCATENATED = MDLib.id("concatenated");

    private static final Map<ResourceLocation, Function<JsonObject, StructurePredicate>> DECODERS = new LinkedHashMap<>();

    static {
        register(ANY, ignored -> AnyPredicate.INSTANCE);
        register(AIR, ignored -> AirPredicate.INSTANCE);
        register(BLOCKS, BlockPredicate::fromJson);
        register(BLOCK_STATES, BlockStatePredicate::fromJson);
        register(BLOCK_TAGS, BlockTagPredicate::fromJson);
        register(FLUIDS, FluidPredicate::fromJson);
        register(FLUID_TAGS, FluidTagPredicate::fromJson);
        register(RESTRICTED, RestrictedPredicate::fromJson);
        register(CONCATENATED, ConcatenatedPredicate::fromJson);
    }

    private StructurePredicateTypes() {}

    public static void register(ResourceLocation type, Function<JsonObject, StructurePredicate> decoder) {
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(decoder, "decoder");
        Function<JsonObject, StructurePredicate> existing = DECODERS.putIfAbsent(type, decoder);
        if (existing != null) {
            throw new IllegalStateException("Duplicate structure predicate type: " + type);
        }
    }

    public static StructurePredicate decode(JsonObject object) {
        if (object == null) {
            throw new IllegalArgumentException("Structure predicate JSON cannot be null");
        }
        String rawType = JsonHelpers.requiredString(object, "type");
        ResourceLocation type = JsonHelpers.parseId(rawType, "predicate type");
        Function<JsonObject, StructurePredicate> decoder = DECODERS.get(type);
        if (decoder == null) {
            decoder = DECODERS.get(MDLib.id(type.getPath()));
        }
        if (decoder == null) {
            throw new IllegalArgumentException("Unknown structure predicate type: " + type);
        }
        return decoder.apply(object);
    }
}
