package com.modularmc.mdl.api.multiblock;

/**
 * Records the controller symbol position inside a built pattern.
 */
public record CenterOffset(int x, int y, int z, int minZ, int maxZ) {}
