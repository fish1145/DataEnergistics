package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;

/**
 * Inclusive bounds of all cells in an expanded pattern.
 *
 * @param min component-wise minimum relative position
 * @param max component-wise maximum relative position
 */
public record PatternBounds(BlockPos min, BlockPos max) {

    public PatternBounds {
        min = min.immutable();
        max = max.immutable();
        if (min.getX() > max.getX() || min.getY() > max.getY() || min.getZ() > max.getZ()) {
            throw new IllegalArgumentException("Pattern bounds minimum must not exceed maximum");
        }
    }
}
