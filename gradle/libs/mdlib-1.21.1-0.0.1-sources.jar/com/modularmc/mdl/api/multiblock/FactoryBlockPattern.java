package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.api.multiblock.util.RelativeDirection;

import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
import it.unimi.dsi.fastutil.chars.Char2ObjectMap;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Builder for string-array multiblock patterns.
 */
public class FactoryBlockPattern {

    private final List<AisleUnit> units = new ArrayList<>();
    private final Char2ObjectMap<TraceabilityPredicate> symbolMap = new Char2ObjectArrayMap<>();
    private final StructureDir structureDir;
    private List<String[]> repeatableGroup;
    private PatternCondition condition;
    private int aisleHeight = -1;
    private int rowWidth = -1;

    private record AisleUnit(List<String[]> slices, int minRepeat, int maxRepeat) {}

    private FactoryBlockPattern(StructureDir structureDir) {
        this.structureDir = structureDir;
        symbolMap.put(' ', Predicates.any());
        symbolMap.put('~', Predicates.controller());
    }

    public static FactoryBlockPattern start() {
        return new FactoryBlockPattern(StructureDir.defaultDirs());
    }

    public static FactoryBlockPattern start(RelativeDirection charDir, RelativeDirection stringDir,
                                            RelativeDirection aisleDir) {
        return new FactoryBlockPattern(new StructureDir(charDir, stringDir, aisleDir));
    }

    public FactoryBlockPattern aisle(String... aisle) {
        validateAisle(aisle);
        if (repeatableGroup == null) {
            units.add(new AisleUnit(List.<String[]>of(copyAisle(aisle)), 1, 1));
        } else {
            repeatableGroup.add(copyAisle(aisle));
        }
        registerSymbols(aisle);
        return this;
    }

    public FactoryBlockPattern beginRepeatable() {
        if (repeatableGroup != null) {
            throw new IllegalStateException("Cannot begin nested repeatable aisle group");
        }
        repeatableGroup = new ArrayList<>();
        return this;
    }

    public FactoryBlockPattern endRepeatable(int minRepeat, int maxRepeat) {
        if (repeatableGroup == null) {
            throw new IllegalStateException("No repeatable aisle group has been started");
        }
        if (repeatableGroup.isEmpty()) {
            throw new IllegalStateException("Repeatable aisle group must contain at least one aisle");
        }
        if (minRepeat <= 0 || maxRepeat <= 0 || minRepeat > maxRepeat) {
            throw new IllegalArgumentException("Repeat bounds must be positive and min <= max");
        }
        units.add(new AisleUnit(List.copyOf(repeatableGroup), minRepeat, maxRepeat));
        repeatableGroup = null;
        return this;
    }

    public FactoryBlockPattern endRepeatable(int repeatCount) {
        return endRepeatable(repeatCount, repeatCount);
    }

    public FactoryBlockPattern where(String symbol, TraceabilityPredicate blockMatcher) {
        if (symbol == null || symbol.length() != 1) {
            throw new IllegalArgumentException("Structure symbol must be exactly one character");
        }
        return where(symbol.charAt(0), blockMatcher);
    }

    public FactoryBlockPattern where(char symbol, TraceabilityPredicate blockMatcher) {
        if (!symbolMap.containsKey(symbol)) {
            throw new IllegalArgumentException("Symbol '" + symbol + "' does not appear in the pattern");
        }
        symbolMap.put(symbol, blockMatcher.isAny() || blockMatcher.isAir() ? blockMatcher :
                new TraceabilityPredicate(blockMatcher).sort());
        return this;
    }

    public FactoryBlockPattern condition(Predicate<MultiblockState> condition) {
        return condition(condition, "mdlib.multiblock.condition_failed");
    }

    public FactoryBlockPattern condition(Predicate<MultiblockState> condition, String translationKey) {
        this.condition = new PatternCondition(condition, translationKey);
        return this;
    }

    public BlockPattern build() {
        if (repeatableGroup != null) {
            throw new IllegalStateException("Repeatable aisle group must be closed before building");
        }
        if (units.isEmpty()) {
            throw new IllegalStateException("Pattern must contain at least one aisle");
        }
        checkMissingPredicates();
        int unitCount = units.size();
        int aisleCount = units.stream().mapToInt(unit -> unit.slices().size()).sum();
        TraceabilityPredicate[][][] blockMatches = new TraceabilityPredicate[aisleCount][aisleHeight][rowWidth];
        String[][] structureSlices = new String[aisleCount][];
        int[][] repetitions = new int[unitCount][];
        int[] starts = new int[unitCount];
        int[] depths = new int[unitCount];
        CenterOffset centerOffset = null;

        int aisleIndex = 0;
        for (int unitIndex = 0, minZ = 0, maxZ = 0; unitIndex < units.size(); unitIndex++) {
            AisleUnit unit = units.get(unitIndex);
            starts[unitIndex] = aisleIndex;
            depths[unitIndex] = unit.slices().size();
            repetitions[unitIndex] = new int[] { unit.minRepeat(), unit.maxRepeat() };
            for (int inner = 0; inner < unit.slices().size(); inner++, aisleIndex++) {
                String[] aisle = unit.slices().get(inner);
                structureSlices[aisleIndex] = copyAisle(aisle);
                for (int y = 0; y < aisleHeight; y++) {
                    for (int x = 0; x < rowWidth; x++) {
                        char symbol = aisle[y].charAt(x);
                        TraceabilityPredicate predicate = symbolMap.get(symbol);
                        blockMatches[aisleIndex][y][x] = predicate;
                        if (symbol == '~') {
                            if (centerOffset != null) {
                                throw new IllegalStateException(
                                        "Pattern must contain exactly one controller symbol '~'");
                            }
                            centerOffset = new CenterOffset(x, y, aisleIndex, Math.addExact(minZ, inner),
                                    Math.addExact(maxZ, inner));
                        }
                    }
                }
            }
            minZ = Math.addExact(minZ, Math.multiplyExact(unit.slices().size(), unit.minRepeat()));
            maxZ = Math.addExact(maxZ, Math.multiplyExact(unit.slices().size(), unit.maxRepeat()));
        }
        if (centerOffset == null) {
            throw new IllegalStateException("Pattern must contain controller symbol '~'");
        }
        Set<TraceabilityPredicate> predicates = new LinkedHashSet<>(symbolMap.values());
        BlockPattern pattern = new BlockPattern(blockMatches, structureDir, repetitions, starts, depths,
                structureSlices, centerOffset, aisleCount, aisleHeight, rowWidth, predicates);
        pattern.condition = condition;
        return pattern;
    }

    private void validateAisle(String... aisle) {
        if (aisle == null || aisle.length == 0) {
            throw new IllegalArgumentException("Aisle cannot be empty");
        }
        if (aisle[0] == null || aisle[0].isEmpty()) {
            throw new IllegalArgumentException("Aisle rows cannot be empty");
        }
        if (aisleHeight == -1) {
            aisleHeight = aisle.length;
            rowWidth = aisle[0].length();
        }
        if (aisle.length != aisleHeight) {
            throw new IllegalArgumentException("Expected aisle height " + aisleHeight + " but got " + aisle.length);
        }
        for (String row : aisle) {
            if (row == null || row.length() != rowWidth) {
                throw new IllegalArgumentException("All aisle rows must have width " + rowWidth);
            }
        }
    }

    private void registerSymbols(String[] aisle) {
        for (String row : aisle) {
            for (int i = 0; i < row.length(); i++) {
                symbolMap.putIfAbsent(row.charAt(i), null);
            }
        }
    }

    private void checkMissingPredicates() {
        StringBuilder missing = new StringBuilder();
        for (char symbol : symbolMap.keySet()) {
            if (symbolMap.get(symbol) == null) {
                if (!missing.isEmpty()) missing.append(',');
                missing.append(symbol);
            }
        }
        if (!missing.isEmpty()) {
            throw new IllegalStateException("Predicates for character(s) " + missing + " are missing");
        }
    }

    private static String[] copyAisle(String[] aisle) {
        return aisle.clone();
    }
}
