package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/**
 * Neutral controller data needed to orient and match a structure.
 */
public interface StructureControllerView {

    /**
     * @return the controller block position.
     */
    BlockPos position();

    /**
     * @return the controller front direction.
     */
    Direction frontFacing();

    /**
     * @return the controller upwards direction used for extended facings.
     */
    Direction upwardsFacing();

    /**
     * @return whether the structure may be mirrored left/right during matching.
     */
    default boolean allowFlip() {
        return true;
    }
}
