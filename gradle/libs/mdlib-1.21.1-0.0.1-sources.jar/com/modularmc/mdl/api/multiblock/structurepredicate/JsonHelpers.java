package com.modularmc.mdl.api.multiblock.structurepredicate;

import net.minecraft.resources.ResourceLocation;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

final class JsonHelpers {

    private JsonHelpers() {}

    static String requiredString(JsonObject object, String field) {
        JsonElement element = object.get(field);
        if (element == null || !element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
            throw new IllegalArgumentException("Expected string field '" + field + "'");
        }
        return element.getAsString();
    }

    static int optionalInt(JsonObject object, String field, int fallback) {
        JsonElement element = object.get(field);
        if (element == null) return fallback;
        if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
            throw new IllegalArgumentException("Expected integer field '" + field + "'");
        }
        try {
            return element.getAsBigDecimal().intValueExact();
        } catch (ArithmeticException | NumberFormatException exception) {
            throw new IllegalArgumentException("Expected integer field '" + field + "'", exception);
        }
    }

    static int optionalInt(JsonObject object, String primaryField, String aliasField, int fallback) {
        boolean hasPrimary = object.has(primaryField);
        boolean hasAlias = object.has(aliasField);
        if (hasPrimary && hasAlias) {
            throw new IllegalArgumentException("Fields '" + primaryField + "' and '" + aliasField +
                    "' cannot both be defined");
        }
        return optionalInt(object, hasPrimary ? primaryField : aliasField, fallback);
    }

    static JsonObject requiredObject(JsonObject object, String field) {
        JsonElement element = object.get(field);
        if (element == null || !element.isJsonObject()) {
            throw new IllegalArgumentException("Expected object field '" + field + "'");
        }
        return element.getAsJsonObject();
    }

    static JsonArray requiredArray(JsonObject object, String field) {
        JsonElement element = object.get(field);
        if (element == null || !element.isJsonArray()) {
            throw new IllegalArgumentException("Expected array field '" + field + "'");
        }
        return element.getAsJsonArray();
    }

    static List<String> oneOrMoreStrings(JsonObject object, String pluralField, String singleField) {
        if (object.has(pluralField)) {
            JsonArray array = requiredArray(object, pluralField);
            if (array.isEmpty()) {
                throw new IllegalArgumentException("Field '" + pluralField + "' must contain at least one value");
            }
            List<String> values = new ArrayList<>();
            for (JsonElement element : array) {
                if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isString()) {
                    throw new IllegalArgumentException("Field '" + pluralField + "' must contain only strings");
                }
                values.add(element.getAsString());
            }
            return values;
        }
        return List.of(requiredString(object, singleField));
    }

    static ResourceLocation parseId(String raw, String label) {
        ResourceLocation id = ResourceLocation.tryParse(raw);
        if (id == null) {
            throw new IllegalArgumentException("Invalid " + label + " id: " + raw);
        }
        return id;
    }
}
