package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.api.multiblock.structurepredicate.StructurePredicate;
import com.modularmc.mdl.api.multiblock.util.RelativeDirection;

import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * Composite predicate assigned to one structure symbol.
 */
public class TraceabilityPredicate {

    private final List<SimplePredicate> common = new ArrayList<>();
    private final List<SimplePredicate> limited = new ArrayList<>();
    private final List<StructurePredicate> structurePredicates = new ArrayList<>();
    private Function<MultiblockState, Direction> direction = state -> null;
    private Direction fixedDirection;
    private RelativeDirection relativeDirection;

    public TraceabilityPredicate() {}

    public TraceabilityPredicate(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates) {
        common.add(new SimplePredicate(predicate, candidates));
    }

    public TraceabilityPredicate(SimplePredicate simplePredicate) {
        addSimplePredicate(simplePredicate);
    }

    public TraceabilityPredicate(StructurePredicate structurePredicate) {
        structurePredicates.add(Objects.requireNonNull(structurePredicate, "structurePredicate"));
    }

    public TraceabilityPredicate(TraceabilityPredicate predicate) {
        common.addAll(predicate.common);
        limited.addAll(predicate.limited);
        structurePredicates.addAll(predicate.structurePredicates);
        direction = predicate.direction;
        fixedDirection = predicate.fixedDirection;
        relativeDirection = predicate.relativeDirection;
    }

    public TraceabilityPredicate sort() {
        limited.sort(Comparator.comparingInt(predicate -> predicate.minCount));
        return this;
    }

    public TraceabilityPredicate setDirection(Direction direction) {
        this.fixedDirection = Objects.requireNonNull(direction, "direction");
        this.relativeDirection = null;
        this.direction = state -> direction;
        return this;
    }

    public TraceabilityPredicate setRelativeDirection(RelativeDirection direction) {
        this.fixedDirection = null;
        this.relativeDirection = Objects.requireNonNull(direction, "direction");
        return this;
    }

    public Direction getDirection(MultiblockState state, Direction frontFacing, Direction upwardsFacing,
                                  boolean isFlipped) {
        if (relativeDirection != null) {
            return relativeDirection.getRelative(frontFacing, upwardsFacing, isFlipped);
        }
        if (fixedDirection != null) {
            return fixedDirection;
        }
        return direction.apply(state);
    }

    public TraceabilityPredicate setMinGlobalLimited(int min) {
        moveCommonToLimited();
        limited.forEach(predicate -> predicate.minCount = min);
        return this;
    }

    public TraceabilityPredicate setMaxGlobalLimited(int max) {
        moveCommonToLimited();
        limited.forEach(predicate -> predicate.maxCount = max);
        return this;
    }

    public TraceabilityPredicate setMinLayerLimited(int min) {
        moveCommonToLimited();
        limited.forEach(predicate -> predicate.minLayerCount = min);
        return this;
    }

    public TraceabilityPredicate setMaxLayerLimited(int max) {
        moveCommonToLimited();
        limited.forEach(predicate -> predicate.maxLayerCount = max);
        return this;
    }

    public TraceabilityPredicate setExactLimit(int limit) {
        return setMinGlobalLimited(limit).setMaxGlobalLimited(limit);
    }

    public TraceabilityPredicate setPreviewCount(int count) {
        common.forEach(predicate -> predicate.previewCount = count);
        limited.forEach(predicate -> predicate.previewCount = count);
        return this;
    }

    public TraceabilityPredicate disableRenderFormed() {
        common.forEach(predicate -> predicate.disableRenderFormed = true);
        limited.forEach(predicate -> predicate.disableRenderFormed = true);
        return this;
    }

    public TraceabilityPredicate setIO(PatternIO io) {
        common.forEach(predicate -> predicate.io = io);
        limited.forEach(predicate -> predicate.io = io);
        return this;
    }

    public TraceabilityPredicate setNBTParser(String nbtParser) {
        common.forEach(predicate -> predicate.nbtParser = nbtParser);
        limited.forEach(predicate -> predicate.nbtParser = nbtParser);
        return this;
    }

    public TraceabilityPredicate setSlotName(String slotName) {
        common.forEach(predicate -> predicate.slotName = slotName);
        limited.forEach(predicate -> predicate.slotName = slotName);
        return this;
    }

    public boolean test(MultiblockState state) {
        state.setIo(PatternIO.BOTH);
        boolean matched = false;
        for (SimplePredicate predicate : limited) {
            if (predicate.testLimited(state)) {
                matched = true;
            }
        }
        matched = matched || common.stream().anyMatch(predicate -> predicate.test(state));
        matched = matched || structurePredicates.stream().anyMatch(predicate -> predicate.test(state, true));
        if (matched) {
            state.setDiagnostic(null);
        }
        return matched;
    }

    public TraceabilityPredicate or(TraceabilityPredicate other) {
        TraceabilityPredicate result = new TraceabilityPredicate(this);
        result.common.addAll(other.common);
        result.limited.addAll(other.limited);
        result.structurePredicates.addAll(other.structurePredicates);
        return result.sort();
    }

    public boolean isAny() {
        return common.stream().anyMatch(predicate -> predicate == SimplePredicate.ANY) ||
                structurePredicates.stream().anyMatch(StructurePredicate::isAny);
    }

    public boolean isAir() {
        return common.stream().anyMatch(predicate -> predicate == SimplePredicate.AIR) ||
                structurePredicates.stream().anyMatch(StructurePredicate::isAir);
    }

    public boolean hasAir() {
        return isAir() || structurePredicates.stream().anyMatch(StructurePredicate::hasAir);
    }

    public boolean addCache() {
        return !isAny();
    }

    public List<Block> blockCandidates() {
        List<Block> result = new ArrayList<>();
        common.forEach(predicate -> result.addAll(predicate.getCandidates()));
        limited.forEach(predicate -> result.addAll(predicate.getCandidates()));
        structurePredicates.forEach(predicate -> result.addAll(predicate.blockCandidates()));
        return List.copyOf(result);
    }

    public List<BlockState> blockStateCandidates() {
        List<BlockState> result = new ArrayList<>();
        common.forEach(predicate -> result.addAll(predicate.getBlockStateCandidates()));
        limited.forEach(predicate -> result.addAll(predicate.getBlockStateCandidates()));
        structurePredicates.forEach(predicate -> result.addAll(predicate.blockStateCandidates()));
        return result.stream().distinct().toList();
    }

    public List<ItemStack> placementCandidates() {
        List<ItemStack> result = new ArrayList<>();
        common.forEach(predicate -> result.addAll(predicate.getPlacementCandidates()));
        limited.forEach(predicate -> result.addAll(predicate.getPlacementCandidates()));
        structurePredicates.forEach(predicate -> result.addAll(predicate.placementCandidates()));
        return deduplicatePlacementCandidates(result);
    }

    private static List<ItemStack> deduplicatePlacementCandidates(List<ItemStack> candidates) {
        List<ItemStack> result = new ArrayList<>();
        for (ItemStack candidate : candidates) {
            if (result.stream().noneMatch(existing -> ItemStack.isSameItemSameComponents(existing, candidate))) {
                result.add(candidate.copy());
            }
        }
        return List.copyOf(result);
    }

    public boolean checkMinimums(MultiblockState state) {
        return checkGlobalMinimums(state) && checkLayerMinimums(state);
    }

    public boolean checkGlobalMinimums(MultiblockState state) {
        for (SimplePredicate predicate : limited) {
            if (!checkSimpleGlobalMinimum(state, predicate)) {
                return false;
            }
        }
        for (StructurePredicate predicate : structurePredicates) {
            if (!predicate.checkGlobalMinimum(state)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkLayerMinimums(MultiblockState state) {
        for (SimplePredicate predicate : limited) {
            if (!checkSimpleLayerMinimum(state, predicate)) {
                return false;
            }
        }
        for (StructurePredicate predicate : structurePredicates) {
            if (!predicate.checkLayerMinimum(state)) {
                return false;
            }
        }
        return true;
    }

    private void addSimplePredicate(SimplePredicate predicate) {
        Objects.requireNonNull(predicate, "predicate");
        if (predicate.minCount != -1 || predicate.maxCount != -1 || predicate.minLayerCount != -1 ||
                predicate.maxLayerCount != -1) {
            limited.add(predicate);
        } else {
            common.add(predicate);
        }
    }

    private void moveCommonToLimited() {
        limited.addAll(common);
        common.clear();
    }

    private static boolean checkSimpleGlobalMinimum(MultiblockState state, SimplePredicate predicate) {
        int global = state.getGlobalCount().getInt(predicate);
        if (predicate.minCount != -1 && global < predicate.minCount) {
            state.setDiagnostic(PatternDiagnostic.of("global_min", "Predicate did not reach global minimum",
                    state.getControllerPos(), predicate.expectedNames()));
            return false;
        }
        return true;
    }

    private static boolean checkSimpleLayerMinimum(MultiblockState state, SimplePredicate predicate) {
        int layer = state.getLayerCount().getInt(predicate);
        if (predicate.minLayerCount != -1 && layer < predicate.minLayerCount) {
            state.setDiagnostic(PatternDiagnostic.of("layer_min", "Predicate did not reach layer minimum",
                    state.getPos(), predicate.expectedNames()));
            return false;
        }
        return true;
    }
}
