package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternCandidate;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Matches blocks in a block tag.
 */
public record BlockTagPredicate(TagKey<Block> tag) implements StructurePredicate {

    public static BlockTagPredicate fromJson(JsonObject object) {
        return new BlockTagPredicate(TagKey.create(Registries.BLOCK,
                JsonHelpers.parseId(JsonHelpers.requiredString(object, "tag"), "block tag")));
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.BLOCK_TAGS;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        boolean matched = state.getBlockState().is(tag);
        if (!matched) {
            state.setDiagnostic(PatternDiagnostic.of("block_tag_mismatch", "Block tag predicate did not match",
                    state.getPos(), List.of("#" + tag.location())));
        }
        return matched;
    }

    @Override
    public List<Block> blockCandidates() {
        return BuiltInRegistries.BLOCK.getTag(tag)
                .map(holders -> holders.stream().map(holder -> holder.value()).toList())
                .orElseGet(List::of);
    }

    @Override
    public List<PatternCandidate> patternCandidates() {
        List<PatternCandidate> candidates = new ArrayList<>();
        for (Block block : blockCandidates()) {
            ItemStack stack = block.asItem().getDefaultInstance();
            if (!stack.isEmpty()) {
                candidates.add(new PatternCandidate(block.defaultBlockState(), stack));
            }
        }
        return List.copyOf(candidates);
    }
}
