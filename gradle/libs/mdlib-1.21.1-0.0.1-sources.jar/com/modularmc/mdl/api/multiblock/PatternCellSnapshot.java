package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;

import java.util.Objects;

/**
 * One structurally immutable cell in an expanded pattern. The predicate reference remains part of the source
 * definition and is not copied.
 *
 * @param relativePosition oriented position relative to the controller
 * @param source           source coordinates and repetition identity
 * @param predicate        predicate assigned to the source symbol
 */
public record PatternCellSnapshot(BlockPos relativePosition, PatternCellSource source,
                                  TraceabilityPredicate predicate) {

    public PatternCellSnapshot {
        relativePosition = relativePosition.immutable();
        source = Objects.requireNonNull(source, "source");
        predicate = Objects.requireNonNull(predicate, "predicate");
    }
}
