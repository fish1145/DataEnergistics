package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternCandidate;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Matches fluid states by fluid type.
 */
public record FluidPredicate(List<Fluid> fluids) implements StructurePredicate {

    public FluidPredicate {
        fluids = List.copyOf(fluids);
        if (fluids.isEmpty()) {
            throw new IllegalArgumentException("Fluid predicate must contain at least one fluid");
        }
    }

    public static FluidPredicate fromJson(JsonObject object) {
        return new FluidPredicate(JsonHelpers.oneOrMoreStrings(object, "fluids", "fluid").stream()
                .map(id -> resolveFluid(JsonHelpers.parseId(id, "fluid")))
                .toList());
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.FLUIDS;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        Fluid fluid = state.getBlockState().getFluidState().getType();
        boolean matched = fluids.contains(fluid);
        if (!matched) {
            state.setDiagnostic(PatternDiagnostic.of("fluid_mismatch", "Fluid predicate did not match", state.getPos(),
                    fluids.stream().map(f -> BuiltInRegistries.FLUID.getKey(f).toString()).toList()));
        }
        return matched;
    }

    @Override
    public List<BlockState> blockStateCandidates() {
        return fluids.stream().map(fluid -> fluid.defaultFluidState().createLegacyBlock()).distinct().toList();
    }

    @Override
    public List<ItemStack> placementCandidates() {
        return fluids.stream().map(Fluid::getBucket).distinct().map(Item::getDefaultInstance)
                .filter(stack -> !stack.isEmpty()).toList();
    }

    @Override
    public List<PatternCandidate> patternCandidates() {
        List<PatternCandidate> candidates = new ArrayList<>();
        for (Fluid fluid : fluids) {
            ItemStack stack = fluid.getBucket().getDefaultInstance();
            if (!stack.isEmpty()) {
                candidates.add(new PatternCandidate(fluid.defaultFluidState().createLegacyBlock(), stack));
            }
        }
        return List.copyOf(candidates);
    }

    private static Fluid resolveFluid(ResourceLocation id) {
        Fluid fluid = BuiltInRegistries.FLUID.get(id);
        if (fluid == null || !id.equals(BuiltInRegistries.FLUID.getKey(fluid))) {
            throw new IllegalStateException("Unknown fluid id in structure predicate: " + id);
        }
        return fluid;
    }
}
