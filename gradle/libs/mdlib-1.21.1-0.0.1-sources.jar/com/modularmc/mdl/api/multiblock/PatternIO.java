package com.modularmc.mdl.api.multiblock;

/**
 * Describes the neutral IO role discovered while matching a structure predicate.
 */
public enum PatternIO {

    NONE,
    IN,
    OUT,
    BOTH;

    /**
     * @return whether this role can satisfy the requested direction.
     */
    public boolean supports(PatternIO requested) {
        if (requested == NONE) return true;
        if (this == BOTH) return requested == IN || requested == OUT || requested == BOTH;
        if (requested == BOTH) return this == BOTH;
        return this == requested;
    }
}
