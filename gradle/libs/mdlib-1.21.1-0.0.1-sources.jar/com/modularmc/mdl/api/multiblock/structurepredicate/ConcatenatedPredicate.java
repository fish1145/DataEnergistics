package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternCandidate;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Logical OR over multiple structure predicates.
 */
public record ConcatenatedPredicate(List<StructurePredicate> predicates) implements StructurePredicate {

    public ConcatenatedPredicate {
        predicates = List.copyOf(predicates);
        if (predicates.isEmpty()) {
            throw new IllegalArgumentException("Concatenated predicate must contain at least one predicate");
        }
    }

    public static ConcatenatedPredicate concat(StructurePredicate first, StructurePredicate second) {
        List<StructurePredicate> predicates = new ArrayList<>();
        if (first instanceof ConcatenatedPredicate concatenated) predicates.addAll(concatenated.predicates);
        else predicates.add(first);
        if (second instanceof ConcatenatedPredicate concatenated) predicates.addAll(concatenated.predicates);
        else predicates.add(second);
        return new ConcatenatedPredicate(predicates);
    }

    public static ConcatenatedPredicate fromJson(JsonObject object) {
        List<StructurePredicate> predicates = new ArrayList<>();
        for (JsonElement element : JsonHelpers.requiredArray(object, "predicates")) {
            if (!element.isJsonObject()) {
                throw new IllegalArgumentException("Concatenated predicate entries must be objects");
            }
            predicates.add(StructurePredicateTypes.decode(element.getAsJsonObject()));
        }
        return new ConcatenatedPredicate(predicates);
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.CONCATENATED;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        return predicates.stream().anyMatch(predicate -> predicate.test(state, mutateCount));
    }

    @Override
    public boolean checkGlobalMinimum(MultiblockState state) {
        for (StructurePredicate predicate : predicates) {
            if (!predicate.checkGlobalMinimum(state)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean checkLayerMinimum(MultiblockState state) {
        for (StructurePredicate predicate : predicates) {
            if (!predicate.checkLayerMinimum(state)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public List<Block> blockCandidates() {
        return predicates.stream().flatMap(predicate -> predicate.blockCandidates().stream()).distinct().toList();
    }

    @Override
    public List<BlockState> blockStateCandidates() {
        return predicates.stream().flatMap(predicate -> predicate.blockStateCandidates().stream()).distinct().toList();
    }

    @Override
    public List<ItemStack> placementCandidates() {
        return predicates.stream().flatMap(predicate -> predicate.placementCandidates().stream()).map(ItemStack::copy)
                .toList();
    }

    @Override
    public List<PatternCandidate> patternCandidates() {
        return predicates.stream().flatMap(predicate -> predicate.patternCandidates().stream()).toList();
    }

    @Override
    public boolean hasAir() {
        return predicates.stream().anyMatch(StructurePredicate::hasAir);
    }
}
