package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;

import net.minecraft.resources.ResourceLocation;

/**
 * Matches any loaded block.
 */
public enum AnyPredicate implements StructurePredicate {

    INSTANCE;

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.ANY;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        return true;
    }
}
