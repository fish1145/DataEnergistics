package com.modularmc.mdl.api.multiblock;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;

import it.unimi.dsi.fastutil.longs.Long2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * Single executable predicate with optional limits and match metadata.
 */
public class SimplePredicate {

    public static final SimplePredicate ANY = new SimplePredicate(state -> true, List::of);
    public static final SimplePredicate AIR = new SimplePredicate(state -> state.getBlockState().isAir(),
            () -> List.of(net.minecraft.world.level.block.Blocks.AIR));

    private final Predicate<MultiblockState> predicate;
    private final Supplier<List<Block>> candidates;
    public int minCount = -1;
    public int maxCount = -1;
    public int minLayerCount = -1;
    public int maxLayerCount = -1;
    public int previewCount = -1;
    public boolean disableRenderFormed;
    public PatternIO io = PatternIO.BOTH;
    public @Nullable String slotName;
    public @Nullable String nbtParser;

    public SimplePredicate(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates) {
        this.predicate = Objects.requireNonNull(predicate, "predicate");
        this.candidates = Objects.requireNonNull(candidates, "candidates");
    }

    public boolean test(MultiblockState state) {
        boolean matched = predicate.test(state);
        if (matched) {
            return checkInnerConditions(state);
        }
        setExpectedDiagnostic(state, "Predicate did not match");
        return false;
    }

    public boolean testLimited(MultiblockState state) {
        if (testGlobal(state) && testLayer(state)) {
            return checkInnerConditions(state);
        }
        return false;
    }

    public boolean testGlobal(MultiblockState state) {
        if (minCount == -1 && maxCount == -1) return predicate.test(state);
        boolean matched = predicate.test(state);
        int count = state.getGlobalCount().mergeInt(this, matched ? 1 : 0, Integer::sum);
        if (!matched) {
            setExpectedDiagnostic(state, "Predicate did not match");
            return false;
        }
        if (maxCount == -1 || count <= maxCount) return true;
        state.setDiagnostic(PatternDiagnostic.of("global_limit", "Predicate exceeded global limit", state.getPos(),
                expectedNames()));
        return false;
    }

    public boolean testLayer(MultiblockState state) {
        if (minLayerCount == -1 && maxLayerCount == -1) return predicate.test(state);
        boolean matched = predicate.test(state);
        int count = state.getLayerCount().mergeInt(this, matched ? 1 : 0, Integer::sum);
        if (!matched) {
            setExpectedDiagnostic(state, "Predicate did not match");
            return false;
        }
        if (maxLayerCount == -1 || count <= maxLayerCount) return true;
        state.setDiagnostic(PatternDiagnostic.of("layer_limit", "Predicate exceeded layer limit", state.getPos(),
                expectedNames()));
        return false;
    }

    public List<Block> getCandidates() {
        List<Block> blocks = candidates.get();
        return blocks == null ? List.of() : List.copyOf(blocks);
    }

    public List<String> expectedNames() {
        List<Block> blocks = getCandidates();
        if (blocks.isEmpty()) return List.of();
        return blocks.stream().map(block -> block.builtInRegistryHolder().key().location().toString()).toList();
    }

    public boolean checkMinimums(MultiblockState state) {
        int global = state.getGlobalCount().getInt(this);
        if (minCount != -1 && global < minCount) {
            state.setDiagnostic(PatternDiagnostic.of("global_min", "Predicate did not reach global minimum",
                    state.getControllerPos(), expectedNames()));
            return false;
        }
        int layer = state.getLayerCount().getInt(this);
        if (minLayerCount != -1 && layer < minLayerCount) {
            state.setDiagnostic(PatternDiagnostic.of("layer_min", "Predicate did not reach layer minimum",
                    state.getControllerPos(), expectedNames()));
            return false;
        }
        return true;
    }

    private boolean checkInnerConditions(MultiblockState state) {
        if (disableRenderFormed) {
            Set<Long> mask = state.getMatchContext().getOrCreate("renderMask", Set.class, HashSet::new);
            mask.add(state.getPos().asLong());
        }
        if (io != PatternIO.BOTH) {
            if (state.getIo() == PatternIO.BOTH) {
                state.setIo(io);
            } else if (state.getIo() != io) {
                state.setIo(PatternIO.NONE);
            }
        }
        if (nbtParser != null) {
            BlockEntity blockEntity = state.getBlockEntity();
            if (blockEntity == null) {
                state.setDiagnostic(PatternDiagnostic.of("nbt_missing", "NBT predicate requires a block entity",
                        state.getPos(), expectedNames()));
                return false;
            }
            CompoundTag tag = blockEntity.saveWithoutMetadata(state.getWorld().registryAccess());
            if (!Pattern.compile(nbtParser).matcher(tag.toString()).find()) {
                state.setDiagnostic(PatternDiagnostic.of("nbt_mismatch", "NBT predicate did not match",
                        state.getPos(), expectedNames()));
                return false;
            }
        }
        if (slotName != null) {
            Long2ObjectMap<Set<String>> slots = state.getMatchContext().getOrCreate("slots", Long2ObjectMap.class,
                    Long2ObjectArrayMap::new);
            slots.computeIfAbsent(state.getPos().asLong(), unused -> new HashSet<>()).add(slotName);
        }
        return true;
    }

    private void setExpectedDiagnostic(MultiblockState state, String message) {
        state.setDiagnostic(PatternDiagnostic.of("predicate_mismatch", message, state.getPos(), expectedNames()));
    }
}
