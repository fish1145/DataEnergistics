package com.modularmc.mdl.api.multiblock;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import it.unimi.dsi.fastutil.longs.Long2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * Single executable predicate with optional limits and match metadata.
 */
public class SimplePredicate {

    public static final SimplePredicate ANY = new SimplePredicate(state -> true, List::of);
    public static final SimplePredicate AIR = new SimplePredicate(state -> state.getBlockState().isAir(),
            () -> List.of(Blocks.AIR));

    private final Predicate<MultiblockState> predicate;
    private final Supplier<List<Block>> candidates;
    private final Supplier<List<BlockState>> blockStateCandidates;
    private final Supplier<List<ItemStack>> placementCandidates;
    private final Supplier<List<PatternCandidate>> patternCandidates;
    public int minCount = -1;
    public int maxCount = -1;
    public int minLayerCount = -1;
    public int maxLayerCount = -1;
    public int previewCount = -1;
    public boolean disableRenderFormed;
    public PatternIO io = PatternIO.BOTH;
    public @Nullable String slotName;
    public @Nullable String nbtParser;

    public SimplePredicate(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates) {
        this(predicate, candidates, () -> defaultBlockStateCandidates(candidates),
                () -> defaultPlacementCandidates(candidates), () -> defaultPatternCandidates(candidates));
    }

    /**
     * Creates an executable predicate with separate preview and placement candidates.
     *
     * @param predicate           matching logic
     * @param candidates          blocks used for diagnostics and default preview states
     * @param placementCandidates stacks a caller may place to satisfy this predicate
     */
    public SimplePredicate(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates,
                           Supplier<List<ItemStack>> placementCandidates) {
        this(predicate, candidates, () -> defaultBlockStateCandidates(candidates), placementCandidates,
                () -> pairLegacyCandidates(defaultBlockStateCandidates(candidates),
                        requirePlacementCandidates(placementCandidates)));
    }

    /**
     * Creates an executable predicate with dynamic, authoritative candidate pairs.
     *
     * @param predicate           matching logic
     * @param candidates          blocks used for diagnostics
     * @param placementCandidates stacks exposed through the legacy placement view
     * @param patternCandidates   authoritative state-to-stack pairs
     */
    public SimplePredicate(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates,
                           Supplier<List<ItemStack>> placementCandidates,
                           Supplier<List<PatternCandidate>> patternCandidates) {
        this(predicate, candidates,
                () -> requirePatternCandidates(patternCandidates.get()).stream()
                        .map(PatternCandidate::previewState)
                        .distinct()
                        .toList(),
                placementCandidates, patternCandidates);
    }

    /**
     * Creates an executable predicate from explicit preview-state and placement-stack pairs.
     *
     * @param predicate         matching logic
     * @param patternCandidates authoritative candidate pairs in their preferred display order
     */
    public SimplePredicate(Predicate<MultiblockState> predicate, List<PatternCandidate> patternCandidates) {
        if (predicate == null) {
            throw new IllegalArgumentException("Predicate cannot be null");
        }
        List<PatternCandidate> stableCandidates = requirePatternCandidates(patternCandidates);
        this.predicate = predicate;
        this.candidates = () -> stableCandidates.stream()
                .map(candidate -> candidate.previewState().getBlock())
                .distinct()
                .toList();
        this.blockStateCandidates = () -> stableCandidates.stream()
                .map(PatternCandidate::previewState)
                .distinct()
                .toList();
        this.placementCandidates = () -> stableCandidates.stream()
                .map(PatternCandidate::placementStack)
                .toList();
        this.patternCandidates = () -> stableCandidates;
    }

    private SimplePredicate(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates,
                            Supplier<List<BlockState>> blockStateCandidates,
                            Supplier<List<ItemStack>> placementCandidates,
                            Supplier<List<PatternCandidate>> patternCandidates) {
        if (predicate == null || candidates == null || blockStateCandidates == null || placementCandidates == null ||
                patternCandidates == null) {
            throw new IllegalArgumentException("Predicate candidate sources cannot be null");
        }
        this.predicate = predicate;
        this.candidates = candidates;
        this.blockStateCandidates = blockStateCandidates;
        this.placementCandidates = placementCandidates;
        this.patternCandidates = patternCandidates;
    }

    public boolean test(MultiblockState state) {
        boolean matched = predicate.test(state);
        if (matched) {
            return checkInnerConditions(state);
        }
        setExpectedDiagnostic(state, "Predicate did not match");
        return false;
    }

    public boolean testLimited(MultiblockState state) {
        if (testGlobal(state) && testLayer(state)) {
            return checkInnerConditions(state);
        }
        return false;
    }

    public boolean testGlobal(MultiblockState state) {
        if (minCount == -1 && maxCount == -1) return predicate.test(state);
        boolean matched = predicate.test(state);
        int count = state.getGlobalCount().mergeInt(this, matched ? 1 : 0, Integer::sum);
        if (!matched) {
            setExpectedDiagnostic(state, "Predicate did not match");
            return false;
        }
        if (maxCount == -1 || count <= maxCount) return true;
        state.setDiagnostic(PatternDiagnostic.of("global_limit", "Predicate exceeded global limit", state.getPos(),
                expectedNames()));
        return false;
    }

    public boolean testLayer(MultiblockState state) {
        if (minLayerCount == -1 && maxLayerCount == -1) return predicate.test(state);
        boolean matched = predicate.test(state);
        int count = state.getLayerCount().mergeInt(this, matched ? 1 : 0, Integer::sum);
        if (!matched) {
            setExpectedDiagnostic(state, "Predicate did not match");
            return false;
        }
        if (maxLayerCount == -1 || count <= maxLayerCount) return true;
        state.setDiagnostic(PatternDiagnostic.of("layer_limit", "Predicate exceeded layer limit", state.getPos(),
                expectedNames()));
        return false;
    }

    public List<Block> getCandidates() {
        return requireCandidates(candidates);
    }

    /**
     * Returns stable block states suitable for structure previews.
     *
     * @return immutable candidate state list
     */
    public List<BlockState> getBlockStateCandidates() {
        return requireBlockStateCandidates(blockStateCandidates);
    }

    /**
     * Returns detached stacks suitable for placement plans and material views.
     *
     * @return immutable list whose mutable stacks are defensive copies
     */
    public List<ItemStack> getPlacementCandidates() {
        return requirePlacementCandidates(placementCandidates);
    }

    /**
     * Returns stable, explicit preview-state and placement-stack pairs.
     *
     * @return immutable candidate list with defensively copied stack accessors
     */
    public List<PatternCandidate> getPatternCandidates() {
        return requirePatternCandidates(patternCandidates.get());
    }

    private static List<BlockState> defaultBlockStateCandidates(Supplier<List<Block>> candidates) {
        return requireCandidates(candidates).stream().map(Block::defaultBlockState).distinct().toList();
    }

    private static List<ItemStack> requirePlacementCandidates(Supplier<List<ItemStack>> placementCandidates) {
        List<ItemStack> stacks = placementCandidates.get();
        if (stacks == null) {
            throw new IllegalStateException("Placement candidate supplier returned null");
        }
        List<ItemStack> copies = new ArrayList<>(stacks.size());
        for (ItemStack stack : stacks) {
            if (stack == null || stack.isEmpty()) {
                throw new IllegalStateException("Placement candidate supplier returned a null or empty stack");
            }
            copies.add(stack.copy());
        }
        return List.copyOf(copies);
    }

    private static List<BlockState> requireBlockStateCandidates(Supplier<List<BlockState>> blockStateCandidates) {
        List<BlockState> states = blockStateCandidates.get();
        if (states == null) {
            throw new IllegalStateException("Block state candidate supplier returned null");
        }
        if (states.stream().anyMatch(state -> state == null)) {
            throw new IllegalStateException("Block state candidate supplier returned a null state");
        }
        return states.stream().distinct().toList();
    }

    private static List<PatternCandidate> defaultPatternCandidates(Supplier<List<Block>> candidates) {
        List<PatternCandidate> result = new ArrayList<>();
        for (Block block : requireCandidates(candidates)) {
            ItemStack stack = block.asItem().getDefaultInstance();
            if (!stack.isEmpty()) {
                addCandidate(result, new PatternCandidate(block.defaultBlockState(), stack));
            }
        }
        return List.copyOf(result);
    }

    private static List<PatternCandidate> pairLegacyCandidates(List<BlockState> states, List<ItemStack> stacks) {
        List<BlockState> uniqueStates = requireStates(states);
        List<ItemStack> uniqueStacks = deduplicateStacks(stacks);
        List<PatternCandidate> defaultCandidates = defaultPatternCandidates(uniqueStates);
        if (sameCandidateStacks(defaultCandidates, uniqueStacks)) {
            return defaultCandidates;
        }
        if (uniqueStates.isEmpty() || uniqueStacks.isEmpty()) {
            throw new IllegalStateException("Legacy custom predicate candidates must provide both preview states " +
                    "and placement stacks");
        }
        if (uniqueStates.size() == 1) {
            return uniqueStacks.stream()
                    .map(stack -> new PatternCandidate(uniqueStates.getFirst(), stack))
                    .toList();
        }
        if (uniqueStacks.size() == 1) {
            return uniqueStates.stream()
                    .map(state -> new PatternCandidate(state, uniqueStacks.getFirst()))
                    .toList();
        }
        throw new IllegalStateException("Legacy custom predicate candidates are ambiguous; provide explicit " +
                "PatternCandidate pairs");
    }

    private static List<PatternCandidate> defaultPatternCandidates(List<BlockState> states) {
        List<PatternCandidate> result = new ArrayList<>();
        for (BlockState state : states) {
            ItemStack stack = state.getBlock().asItem().getDefaultInstance();
            if (!stack.isEmpty()) {
                addCandidate(result, new PatternCandidate(state, stack));
            }
        }
        return List.copyOf(result);
    }

    private static List<BlockState> requireStates(List<BlockState> states) {
        if (states == null) {
            throw new IllegalStateException("Block state candidate list cannot be null");
        }
        if (states.stream().anyMatch(state -> state == null)) {
            throw new IllegalStateException("Block state candidate list cannot contain null");
        }
        return states.stream().distinct().toList();
    }

    private static List<ItemStack> deduplicateStacks(List<ItemStack> stacks) {
        if (stacks == null) {
            throw new IllegalStateException("Placement candidate list cannot be null");
        }
        List<ItemStack> result = new ArrayList<>();
        for (ItemStack stack : stacks) {
            if (stack == null || stack.isEmpty()) {
                throw new IllegalStateException("Placement candidate list cannot contain null or empty stacks");
            }
            if (result.stream().noneMatch(existing -> ItemStack.isSameItemSameComponents(existing, stack))) {
                result.add(stack.copy());
            }
        }
        return List.copyOf(result);
    }

    private static boolean sameCandidateStacks(List<PatternCandidate> candidates, List<ItemStack> stacks) {
        List<ItemStack> expectedStacks = deduplicateStacks(candidates.stream()
                .map(PatternCandidate::placementStack)
                .toList());
        if (expectedStacks.size() != stacks.size()) {
            return false;
        }
        return expectedStacks.stream().allMatch(expected -> stacks.stream().anyMatch(
                stack -> ItemStack.isSameItemSameComponents(expected, stack)));
    }

    private static List<PatternCandidate> requirePatternCandidates(List<PatternCandidate> candidates) {
        if (candidates == null) {
            throw new IllegalStateException("Pattern candidate list cannot be null");
        }
        if (candidates.stream().anyMatch(candidate -> candidate == null)) {
            throw new IllegalStateException("Pattern candidate list cannot contain null");
        }
        return List.copyOf(candidates);
    }

    private static void addCandidate(List<PatternCandidate> candidates, PatternCandidate candidate) {
        boolean duplicate = candidates.stream()
                .anyMatch(existing -> existing.previewState().equals(candidate.previewState()) &&
                        ItemStack.isSameItemSameComponents(
                                existing.placementStack(), candidate.placementStack()));
        if (!duplicate) {
            candidates.add(candidate);
        }
    }

    private static List<ItemStack> defaultPlacementCandidates(Supplier<List<Block>> candidates) {
        List<ItemStack> stacks = new ArrayList<>();
        Set<Item> seenItems = new LinkedHashSet<>();
        for (Block block : requireCandidates(candidates)) {
            Item item = block.asItem();
            if (seenItems.add(item)) {
                ItemStack stack = item.getDefaultInstance();
                if (!stack.isEmpty()) {
                    stacks.add(stack);
                }
            }
        }
        return List.copyOf(stacks);
    }

    private static List<Block> requireCandidates(Supplier<List<Block>> candidates) {
        List<Block> blocks = candidates.get();
        if (blocks == null) {
            throw new IllegalStateException("Block candidate supplier returned null");
        }
        return List.copyOf(blocks);
    }

    public List<String> expectedNames() {
        List<Block> blocks = getCandidates();
        if (blocks.isEmpty()) return List.of();
        return blocks.stream().map(block -> block.builtInRegistryHolder().key().location().toString()).toList();
    }

    public boolean checkMinimums(MultiblockState state) {
        int global = state.getGlobalCount().getInt(this);
        if (minCount != -1 && global < minCount) {
            state.setDiagnostic(PatternDiagnostic.of("global_min", "Predicate did not reach global minimum",
                    state.getControllerPos(), expectedNames()));
            return false;
        }
        int layer = state.getLayerCount().getInt(this);
        if (minLayerCount != -1 && layer < minLayerCount) {
            state.setDiagnostic(PatternDiagnostic.of("layer_min", "Predicate did not reach layer minimum",
                    state.getControllerPos(), expectedNames()));
            return false;
        }
        return true;
    }

    private boolean checkInnerConditions(MultiblockState state) {
        if (disableRenderFormed) {
            Set<Long> mask = state.getMatchContext().getOrCreate("renderMask", Set.class, HashSet::new);
            mask.add(state.getPos().asLong());
        }
        if (io != PatternIO.BOTH) {
            if (state.getIo() == PatternIO.BOTH) {
                state.setIo(io);
            } else if (state.getIo() != io) {
                state.setIo(PatternIO.NONE);
            }
        }
        if (nbtParser != null) {
            BlockEntity blockEntity = state.getBlockEntity();
            if (blockEntity == null) {
                state.setDiagnostic(PatternDiagnostic.of("nbt_missing", "NBT predicate requires a block entity",
                        state.getPos(), expectedNames()));
                return false;
            }
            CompoundTag tag = blockEntity.saveWithoutMetadata(state.getWorld().registryAccess());
            if (!Pattern.compile(nbtParser).matcher(tag.toString()).find()) {
                state.setDiagnostic(PatternDiagnostic.of("nbt_mismatch", "NBT predicate did not match",
                        state.getPos(), expectedNames()));
                return false;
            }
        }
        if (slotName != null) {
            Long2ObjectMap<Set<String>> slots = state.getMatchContext().getOrCreate("slots", Long2ObjectMap.class,
                    Long2ObjectArrayMap::new);
            slots.computeIfAbsent(state.getPos().asLong(), unused -> new HashSet<>()).add(slotName);
        }
        return true;
    }

    private void setExpectedDiagnostic(MultiblockState state, String message) {
        state.setDiagnostic(PatternDiagnostic.of("predicate_mismatch", message, state.getPos(), expectedNames()));
    }
}
