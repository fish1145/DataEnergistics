package com.modularmc.mdl.api.multiblock;

/**
 * Source identity for one expanded aisle layer.
 *
 * @param unitIndex   source unit index
 * @param repeatIndex repetition inside the unit
 * @param innerLayer  aisle index inside one unit repetition
 * @param sourceLayer unexpanded source aisle index
 */
public record PatternLayerSource(int unitIndex, int repeatIndex, int innerLayer, int sourceLayer) {

    public PatternLayerSource {
        if (unitIndex < 0 || repeatIndex < 0 || innerLayer < 0 || sourceLayer < 0) {
            throw new IllegalArgumentException("Pattern layer source coordinates cannot be negative");
        }
    }
}
