package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.Property;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.List;
import java.util.Objects;

/**
 * Matches exact block states, including optional serialized properties.
 */
public record BlockStatePredicate(List<BlockState> blockStates) implements StructurePredicate {

    public BlockStatePredicate {
        blockStates = List.copyOf(Objects.requireNonNull(blockStates, "blockStates"));
        if (blockStates.isEmpty()) {
            throw new IllegalArgumentException("Block state predicate must contain at least one state");
        }
    }

    public static BlockStatePredicate fromJson(JsonObject object) {
        if (object.has("block_states")) {
            return new BlockStatePredicate(JsonHelpers.requiredArray(object, "block_states").asList().stream()
                    .map(BlockStatePredicate::parseState)
                    .toList());
        }
        return new BlockStatePredicate(List.of(parseState(object)));
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.BLOCK_STATES;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        boolean matched = blockStates.contains(state.getBlockState());
        if (!matched) {
            state.setDiagnostic(PatternDiagnostic.of("block_state_mismatch", "Block state predicate did not match",
                    state.getPos(), blockStates.stream().map(Object::toString).toList()));
        }
        return matched;
    }

    @Override
    public List<Block> blockCandidates() {
        return blockStates.stream().map(BlockState::getBlock).distinct().toList();
    }

    @Override
    public List<BlockState> blockStateCandidates() {
        return blockStates;
    }

    @Override
    public boolean hasAir() {
        return blockStates.contains(Blocks.AIR.defaultBlockState());
    }

    private static BlockState parseState(JsonElement element) {
        if (!element.isJsonObject()) {
            throw new IllegalArgumentException("Block state predicate entries must be objects");
        }
        JsonObject object = element.getAsJsonObject();
        Block block = BlockPredicate.resolveBlock(JsonHelpers.parseId(JsonHelpers.requiredString(object, "block"),
                "block"));
        BlockState state = block.defaultBlockState();
        if (!object.has("properties")) {
            return state;
        }
        JsonObject properties = JsonHelpers.requiredObject(object, "properties");
        StateDefinition<Block, BlockState> definition = block.getStateDefinition();
        for (String key : properties.keySet()) {
            Property<?> property = definition.getProperty(key);
            if (property == null) {
                throw new IllegalArgumentException("Unknown block state property '" + key + "' for " + block);
            }
            state = applyProperty(state, property, JsonHelpers.requiredString(properties, key));
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState applyProperty(BlockState state, Property<T> property,
                                                                      String value) {
        T parsed = property.getValue(value).orElseThrow(
                () -> new IllegalArgumentException("Invalid value '" + value + "' for property " + property.getName()));
        return state.setValue(property, parsed);
    }
}
