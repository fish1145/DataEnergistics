package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.api.multiblock.structurepredicate.AirPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.AnyPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.BlockPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.BlockStatePredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.BlockTagPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.ControllerAnchorPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.FluidPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.FluidTagPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.StructurePredicate;

import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * Factory methods for common structure predicates.
 */
public final class Predicates {

    private Predicates() {}

    public static TraceabilityPredicate any() {
        return new TraceabilityPredicate(AnyPredicate.INSTANCE);
    }

    public static TraceabilityPredicate air() {
        return new TraceabilityPredicate(AirPredicate.INSTANCE);
    }

    public static TraceabilityPredicate controller() {
        return new TraceabilityPredicate(ControllerAnchorPredicate.INSTANCE);
    }

    public static TraceabilityPredicate blocks(Block... blocks) {
        return new TraceabilityPredicate(new BlockPredicate(Arrays.asList(blocks)));
    }

    public static TraceabilityPredicate states(BlockState... states) {
        return new TraceabilityPredicate(new BlockStatePredicate(Arrays.asList(states)));
    }

    public static TraceabilityPredicate blockTag(TagKey<Block> tag) {
        return new TraceabilityPredicate(new BlockTagPredicate(tag));
    }

    public static TraceabilityPredicate fluids(Fluid... fluids) {
        return new TraceabilityPredicate(new FluidPredicate(Arrays.asList(fluids)));
    }

    public static TraceabilityPredicate fluidTag(TagKey<Fluid> tag) {
        return new TraceabilityPredicate(new FluidTagPredicate(tag));
    }

    public static TraceabilityPredicate from(StructurePredicate predicate) {
        return new TraceabilityPredicate(predicate);
    }

    public static SimplePredicate custom(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates) {
        return new SimplePredicate(predicate, candidates);
    }

    /**
     * Creates a custom predicate from authoritative preview-state and placement-stack pairs.
     *
     * @param predicate         matching logic
     * @param patternCandidates candidate pairs in their preferred display order
     * @return configured predicate
     */
    public static SimplePredicate custom(Predicate<MultiblockState> predicate,
                                         List<PatternCandidate> patternCandidates) {
        return new SimplePredicate(predicate, patternCandidates);
    }

    /**
     * Creates a custom predicate with dynamic, authoritative candidate pairs.
     *
     * @param predicate           matching logic
     * @param candidates          blocks used for diagnostics
     * @param placementCandidates stacks exposed through the legacy placement view
     * @param patternCandidates   authoritative state-to-stack pairs
     * @return configured predicate
     */
    public static SimplePredicate custom(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates,
                                         Supplier<List<ItemStack>> placementCandidates,
                                         Supplier<List<PatternCandidate>> patternCandidates) {
        return new SimplePredicate(predicate, candidates, placementCandidates, patternCandidates);
    }

    /**
     * Creates a custom predicate whose material candidate cannot be derived from its diagnostic blocks.
     *
     * @param predicate           matching logic
     * @param candidates          blocks used for diagnostics and default preview states
     * @param placementCandidates stacks exposed to placement and material consumers
     * @return configured predicate
     */
    public static SimplePredicate custom(Predicate<MultiblockState> predicate, Supplier<List<Block>> candidates,
                                         Supplier<List<ItemStack>> placementCandidates) {
        return new SimplePredicate(predicate, candidates, placementCandidates);
    }
}
