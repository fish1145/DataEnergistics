package com.modularmc.mdl.api.multiblock;

/**
 * Describes one contiguous, optionally repeatable group of source aisles.
 *
 * @param index       stable unit index in source order
 * @param sourceStart first source aisle index
 * @param depth       number of source aisles in one repetition
 * @param repeats     legal repeat range
 */
public record PatternUnit(int index, int sourceStart, int depth, RepeatRange repeats) {

    public PatternUnit {
        if (index < 0 || sourceStart < 0 || depth <= 0) {
            throw new IllegalArgumentException("Invalid pattern unit metadata");
        }
        if (repeats == null) {
            throw new NullPointerException("Pattern unit repeat range cannot be null");
        }
    }

    /**
     * @return the first source aisle index after this unit
     */
    public int sourceEndExclusive() {
        return Math.addExact(sourceStart, depth);
    }
}
