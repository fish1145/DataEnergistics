package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import org.jetbrains.annotations.Nullable;

/**
 * Read-only world access required by the structure matching core.
 */
public interface StructureWorldView {

    /**
     * @return whether the position can be read safely.
     */
    boolean isLoaded(BlockPos pos);

    /**
     * @return the block state at the loaded position.
     */
    BlockState getBlockState(BlockPos pos);

    /**
     * @return the block entity at the loaded position, or null when absent.
     */
    @Nullable
    BlockEntity getBlockEntity(BlockPos pos);

    /**
     * @return registry lookup needed when a predicate reads block entity NBT.
     */
    default HolderLookup.Provider registryAccess() {
        throw new UnsupportedOperationException("StructureWorldView must provide registry access for NBT predicates");
    }
}
