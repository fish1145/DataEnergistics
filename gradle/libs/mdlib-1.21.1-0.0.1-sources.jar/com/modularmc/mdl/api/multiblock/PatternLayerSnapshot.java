package com.modularmc.mdl.api.multiblock;

import java.util.List;
import java.util.Objects;

/**
 * One immutable layer in an expanded pattern.
 *
 * @param index  expanded layer index
 * @param source source unit and repetition identity
 * @param cells  immutable cells in row-major order
 */
public record PatternLayerSnapshot(int index, PatternLayerSource source, List<PatternCellSnapshot> cells) {

    public PatternLayerSnapshot {
        if (index < 0) {
            throw new IllegalArgumentException("Expanded layer index cannot be negative");
        }
        source = Objects.requireNonNull(source, "source");
        cells = List.copyOf(cells);
        if (cells.isEmpty()) {
            throw new IllegalArgumentException("Expanded pattern layer must contain at least one cell");
        }
        for (PatternCellSnapshot cell : cells) {
            PatternCellSource cellSource = cell.source();
            if (cellSource.unitIndex() != source.unitIndex() ||
                    cellSource.repeatIndex() != source.repeatIndex() ||
                    cellSource.sourceLayer() != source.sourceLayer()) {
                throw new IllegalArgumentException("Expanded layer contains a cell from a different source layer");
            }
        }
    }
}
