package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;

/**
 * Immutable result returned by the structure matcher.
 */
public record StructureMatchResult(
                                   boolean matched,
                                   boolean flipped,
                                   Direction frontFacing,
                                   List<BlockPos> positions,
                                   PatternMatchContext context,
                                   @Nullable PatternDiagnostic diagnostic) {

    public StructureMatchResult {
        Objects.requireNonNull(frontFacing, "frontFacing");
        positions = positions == null ? List.of() : List.copyOf(positions);
        context = context == null ? new PatternMatchContext() : context.copy();
        if (matched && diagnostic != null) {
            throw new IllegalArgumentException("Successful structure match cannot carry a diagnostic");
        }
    }

    public static StructureMatchResult success(boolean flipped, Direction frontFacing, List<BlockPos> positions,
                                               PatternMatchContext context) {
        return new StructureMatchResult(true, flipped, frontFacing, positions, context, null);
    }

    public static StructureMatchResult failure(Direction frontFacing, PatternMatchContext context,
                                               PatternDiagnostic diagnostic) {
        return new StructureMatchResult(false, false, frontFacing, List.of(), context,
                Objects.requireNonNull(diagnostic, "diagnostic"));
    }
}
