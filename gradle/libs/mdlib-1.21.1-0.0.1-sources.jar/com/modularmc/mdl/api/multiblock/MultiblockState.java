package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.api.multiblock.structurepredicate.StructurePredicate;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Mutable state shared by predicates during one structure match attempt.
 */
public final class MultiblockState {

    private final StructureWorldView world;
    private final BlockPos controllerPos;
    private final String structureName;
    private final PatternMatchContext matchContext = new PatternMatchContext();
    private final Object2IntOpenHashMap<SimplePredicate> globalCount = new Object2IntOpenHashMap<>();
    private final Object2IntOpenHashMap<SimplePredicate> layerCount = new Object2IntOpenHashMap<>();
    private final Object2IntOpenHashMap<StructurePredicate> structureGlobalCount = new Object2IntOpenHashMap<>();
    private final Object2IntOpenHashMap<StructurePredicate> structureLayerCount = new Object2IntOpenHashMap<>();
    private final List<BlockPos> matchedPositions = new ArrayList<>();
    private BlockPos pos;
    private BlockState blockState;
    private BlockEntity blockEntity;
    private boolean blockEntityInitialized;
    private TraceabilityPredicate predicate;
    private PatternIO io = PatternIO.BOTH;
    private PatternDiagnostic diagnostic;

    public MultiblockState(StructureWorldView world, BlockPos controllerPos, String structureName) {
        this.world = Objects.requireNonNull(world, "world");
        this.controllerPos = Objects.requireNonNull(controllerPos, "controllerPos").immutable();
        if (structureName == null || structureName.isBlank()) {
            throw new IllegalArgumentException("Structure name cannot be blank");
        }
        this.structureName = structureName;
    }

    public void clean() {
        matchContext.reset();
        globalCount.clear();
        layerCount.clear();
        structureGlobalCount.clear();
        structureLayerCount.clear();
        matchedPositions.clear();
        diagnostic = null;
        pos = null;
        blockState = null;
        blockEntity = null;
        blockEntityInitialized = false;
        predicate = null;
        io = PatternIO.BOTH;
    }

    public boolean update(BlockPos pos, TraceabilityPredicate predicate) {
        this.pos = Objects.requireNonNull(pos, "pos").immutable();
        this.predicate = Objects.requireNonNull(predicate, "predicate");
        this.blockState = null;
        this.blockEntity = null;
        this.blockEntityInitialized = false;
        this.io = PatternIO.BOTH;
        this.diagnostic = null;
        if (!world.isLoaded(pos)) {
            setDiagnostic(PatternDiagnostic.of("unloaded", "Position is not loaded", pos, List.of()));
            return false;
        }
        return true;
    }

    public StructureWorldView getWorld() {
        return world;
    }

    public BlockPos getControllerPos() {
        return controllerPos;
    }

    public String getStructureName() {
        return structureName;
    }

    public PatternMatchContext getMatchContext() {
        return matchContext;
    }

    public Object2IntOpenHashMap<SimplePredicate> getGlobalCount() {
        return globalCount;
    }

    public Object2IntOpenHashMap<SimplePredicate> getLayerCount() {
        return layerCount;
    }

    public Object2IntOpenHashMap<StructurePredicate> getStructureGlobalCount() {
        return structureGlobalCount;
    }

    public Object2IntOpenHashMap<StructurePredicate> getStructureLayerCount() {
        return structureLayerCount;
    }

    public TraceabilityPredicate getPredicate() {
        return predicate;
    }

    public PatternIO getIo() {
        return io;
    }

    public void setIo(PatternIO io) {
        this.io = Objects.requireNonNull(io, "io");
    }

    public boolean hasDiagnostic() {
        return diagnostic != null;
    }

    public @Nullable PatternDiagnostic getDiagnostic() {
        return diagnostic;
    }

    public void setDiagnostic(@Nullable PatternDiagnostic diagnostic) {
        this.diagnostic = diagnostic;
    }

    public BlockState getBlockState() {
        requireCurrentPosition();
        if (blockState == null) {
            blockState = world.getBlockState(pos);
            if (blockState == null) {
                throw new IllegalStateException("StructureWorldView returned null BlockState at " + pos);
            }
        }
        return blockState;
    }

    public @Nullable BlockEntity getBlockEntity() {
        requireCurrentPosition();
        if (!getBlockState().hasBlockEntity()) {
            return null;
        }
        if (!blockEntityInitialized) {
            blockEntity = world.getBlockEntity(pos);
            blockEntityInitialized = true;
        }
        return blockEntity;
    }

    public BlockPos getPos() {
        requireCurrentPosition();
        return pos;
    }

    public void addMatchedPosition(BlockPos pos) {
        matchedPositions.add(Objects.requireNonNull(pos, "pos").immutable());
    }

    public int matchedPositionCount() {
        return matchedPositions.size();
    }

    public void truncateMatchedPositions(int size) {
        if (size < 0 || size > matchedPositions.size()) {
            throw new IllegalArgumentException("Invalid matched position rollback size: " + size);
        }
        while (matchedPositions.size() > size) {
            matchedPositions.removeLast();
        }
    }

    public List<BlockPos> getMatchedPositions() {
        return List.copyOf(matchedPositions);
    }

    Snapshot snapshot() {
        return new Snapshot(matchContext.snapshot(), copyCount(globalCount), copyCount(layerCount),
                copyCount(structureGlobalCount), copyCount(structureLayerCount), List.copyOf(matchedPositions), pos,
                blockState, blockEntity, blockEntityInitialized, predicate, io, diagnostic);
    }

    void restore(Snapshot snapshot) {
        Objects.requireNonNull(snapshot, "snapshot");
        matchContext.restore(snapshot.matchContext);
        restoreCount(globalCount, snapshot.globalCount);
        restoreCount(layerCount, snapshot.layerCount);
        restoreCount(structureGlobalCount, snapshot.structureGlobalCount);
        restoreCount(structureLayerCount, snapshot.structureLayerCount);
        matchedPositions.clear();
        matchedPositions.addAll(snapshot.matchedPositions);
        pos = snapshot.pos;
        blockState = snapshot.blockState;
        blockEntity = snapshot.blockEntity;
        blockEntityInitialized = snapshot.blockEntityInitialized;
        predicate = snapshot.predicate;
        io = snapshot.io;
        diagnostic = snapshot.diagnostic;
    }

    private void requireCurrentPosition() {
        if (pos == null) {
            throw new IllegalStateException("MultiblockState has no current position");
        }
    }

    private static <T> Object2IntOpenHashMap<T> copyCount(Object2IntOpenHashMap<T> source) {
        Object2IntOpenHashMap<T> copy = new Object2IntOpenHashMap<>(source);
        copy.defaultReturnValue(source.defaultReturnValue());
        return copy;
    }

    private static <T> void restoreCount(Object2IntOpenHashMap<T> target, Object2IntOpenHashMap<T> source) {
        target.clear();
        target.putAll(source);
        target.defaultReturnValue(source.defaultReturnValue());
    }

    record Snapshot(
                    PatternMatchContext.Snapshot matchContext,
                    Object2IntOpenHashMap<SimplePredicate> globalCount,
                    Object2IntOpenHashMap<SimplePredicate> layerCount,
                    Object2IntOpenHashMap<StructurePredicate> structureGlobalCount,
                    Object2IntOpenHashMap<StructurePredicate> structureLayerCount,
                    List<BlockPos> matchedPositions,
                    @Nullable BlockPos pos,
                    @Nullable BlockState blockState,
                    @Nullable BlockEntity blockEntity,
                    boolean blockEntityInitialized,
                    @Nullable TraceabilityPredicate predicate,
                    PatternIO io,
                    @Nullable PatternDiagnostic diagnostic) {}
}
