package com.modularmc.mdl.api.multiblock;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Couples one exact preview state with the item stack used to place or account for it.
 *
 * @param previewState   exact state rendered by structure preview consumers
 * @param placementStack component-aware stack used by placement and material consumers
 */
public record PatternCandidate(BlockState previewState, ItemStack placementStack) {

    /**
     * Creates an immutable candidate pair and detaches its mutable item stack.
     *
     * @param previewState   exact state rendered by structure preview consumers
     * @param placementStack non-empty stack used by placement and material consumers
     */
    public PatternCandidate {
        if (previewState == null) {
            throw new IllegalArgumentException("Pattern candidate preview state cannot be null");
        }
        if (placementStack == null || placementStack.isEmpty()) {
            throw new IllegalArgumentException("Pattern candidate placement stack cannot be null or empty");
        }
        placementStack = placementStack.copy();
    }

    /**
     * Returns the exact state associated with this candidate.
     *
     * @return immutable block state
     */
    public BlockState previewState() {
        return previewState;
    }

    /**
     * Returns a detached copy of the placement stack.
     *
     * @return caller-owned stack retaining all data components
     */
    public ItemStack placementStack() {
        return placementStack.copy();
    }
}
