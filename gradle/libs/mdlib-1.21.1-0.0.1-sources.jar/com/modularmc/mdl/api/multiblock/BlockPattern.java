package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.api.multiblock.util.RelativeDirection;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Immutable multiblock pattern made from aisle slices and traceability predicates.
 */
public class BlockPattern {

    /** Maximum cells one pattern definition may visit during matching or default projection. */
    public static final int MAX_PATTERN_CELLS = 1_000_000;

    /**
     * Legacy read-only snapshot of unit repeat ranges.
     *
     * @deprecated use {@link #getLayout()}; mutating this array never changes the pattern
     */
    @Deprecated(forRemoval = false)
    public final int[][] aisleRepetitions;

    /**
     * Legacy read-only snapshot of unit source starts.
     *
     * @deprecated use {@link #getLayout()}; mutating this array never changes the pattern
     */
    @Deprecated(forRemoval = false)
    public final int[] unitStarts;

    /**
     * Legacy read-only snapshot of unit source depths.
     *
     * @deprecated use {@link #getLayout()}; mutating this array never changes the pattern
     */
    @Deprecated(forRemoval = false)
    public final int[] unitDepths;
    public final StructureDir structureDir;
    public final String[][] structureSlices;
    private final int[][] repeatRanges;
    private final int[] sourceStarts;
    private final int[] sourceDepths;
    private final TraceabilityPredicate[][][] blockMatches;
    private final int fingerLength;
    private final int thumbLength;
    private final int palmLength;
    private final CenterOffset centerOffset;
    private final PatternLayout layout;
    private final Collection<TraceabilityPredicate> predicates;
    public PatternCondition condition;

    public BlockPattern(TraceabilityPredicate[][][] predicates, StructureDir structureDir, int[][] aisleRepetitions,
                        int[] unitStarts, int[] unitDepths, String[][] structureSlices, CenterOffset centerOffset,
                        int fingerLength, int thumbLength, int palmLength,
                        Collection<TraceabilityPredicate> symbolPredicates) {
        this.blockMatches = copyPredicates(predicates);
        this.structureDir = Objects.requireNonNull(structureDir, "structureDir");
        this.repeatRanges = copy2d(aisleRepetitions);
        this.sourceStarts = Arrays.copyOf(unitStarts, unitStarts.length);
        this.sourceDepths = Arrays.copyOf(unitDepths, unitDepths.length);
        this.aisleRepetitions = copy2d(this.repeatRanges);
        this.unitStarts = Arrays.copyOf(this.sourceStarts, this.sourceStarts.length);
        this.unitDepths = Arrays.copyOf(this.sourceDepths, this.sourceDepths.length);
        this.structureSlices = copySlices(structureSlices);
        this.centerOffset = Objects.requireNonNull(centerOffset, "centerOffset");
        this.fingerLength = fingerLength;
        this.thumbLength = thumbLength;
        this.palmLength = palmLength;
        this.predicates = List.copyOf(symbolPredicates);
        validateShape();
        validateMaximumSize();
        this.layout = PatternLayout.from(this);
    }

    public StructureMatchResult checkPatternAt(StructureWorldView world, StructureControllerView controller,
                                               String structureName) {
        MultiblockState state = new MultiblockState(world, controller.position(), structureName);
        StructureMatchResult result = checkPatternAt(state, controller.position(), controller.frontFacing(),
                controller.upwardsFacing(), false);
        if (!result.matched() && controller.allowFlip()) {
            result = checkPatternAt(state, controller.position(), controller.frontFacing(), controller.upwardsFacing(),
                    true);
        }
        return result;
    }

    public StructureMatchResult checkPatternAt(MultiblockState state, BlockPos centerPos, Direction frontFacing,
                                               Direction upwardsFacing, boolean isFlipped) {
        return checkPatternAt(state, centerPos, frontFacing, upwardsFacing, isFlipped, MAX_PATTERN_CELLS);
    }

    StructureMatchResult checkPatternAt(MultiblockState state, BlockPos centerPos, Direction frontFacing,
                                        Direction upwardsFacing, boolean isFlipped, int maxVisitedCells) {
        MatchBudget budget = new MatchBudget(maxVisitedCells);
        state.clean();
        PatternDiagnostic lastDiagnostic = null;
        boolean foundFirstAisle = false;
        int firstAisleSearchStart = -centerOffset.maxZ();
        int forward = firstAisleSearchStart++;
        for (int unitIndex = 0; unitIndex < repeatRanges.length; unitIndex++) {
            int minRepeat = repeatRanges[unitIndex][0];
            int maxRepeat = repeatRanges[unitIndex][1];
            int matchedRepeat = 0;
            for (int repeat = 0; foundFirstAisle ? repeat < maxRepeat : forward <= -centerOffset.minZ(); repeat++) {
                int repeatStartForward = forward;
                MatchAttempt attempt = tryMatchUnit(state, centerPos, frontFacing, upwardsFacing, isFlipped, unitIndex,
                        forward, budget);
                if (!attempt.success()) {
                    if (budget.exceeded()) {
                        return StructureMatchResult.failure(frontFacing, state.getMatchContext(), attempt.diagnostic());
                    }
                    lastDiagnostic = attempt.diagnostic();
                    if (foundFirstAisle) {
                        if (matchedRepeat < minRepeat) {
                            unitIndex = -1;
                            foundFirstAisle = false;
                            forward = firstAisleSearchStart++;
                            state.clean();
                            break;
                        }
                        forward = repeatStartForward;
                        break;
                    }
                    forward = repeatStartForward + 1;
                    continue;
                }
                foundFirstAisle = true;
                matchedRepeat++;
                forward += sourceDepths[unitIndex];
            }
            if (unitIndex == -1) {
                continue;
            }
            if (!foundFirstAisle || matchedRepeat < minRepeat) {
                return StructureMatchResult.failure(frontFacing, state.getMatchContext(),
                        failedSearchDiagnostic(centerPos, lastDiagnostic));
            }
        }

        for (TraceabilityPredicate predicate : predicates) {
            if (!predicate.checkGlobalMinimums(state)) {
                return StructureMatchResult.failure(frontFacing, state.getMatchContext(), state.getDiagnostic());
            }
        }
        if (condition != null && !condition.condition().test(state)) {
            return StructureMatchResult.failure(frontFacing, state.getMatchContext(),
                    PatternDiagnostic.of("condition", "Pattern condition failed: " + condition.translationKey(),
                            centerPos, List.of()));
        }
        return StructureMatchResult.success(isFlipped, frontFacing, state.getMatchedPositions(),
                state.getMatchContext());
    }

    private PatternDiagnostic failedSearchDiagnostic(BlockPos centerPos, PatternDiagnostic lastDiagnostic) {
        if (lastDiagnostic != null) {
            return lastDiagnostic;
        }
        return PatternDiagnostic.of("pattern_mismatch", "Structure pattern did not match", centerPos, List.of());
    }

    public int[] getDimensions() {
        return new int[] { fingerLength, thumbLength, palmLength };
    }

    /** @return immutable controller offset metadata */
    public CenterOffset getCenterOffset() {
        return centerOffset;
    }

    /** @return unexpanded source aisle count */
    public int getFingerLength() {
        return fingerLength;
    }

    /** @return row count per source aisle */
    public int getThumbLength() {
        return thumbLength;
    }

    /** @return character count per row */
    public int getPalmLength() {
        return palmLength;
    }

    /**
     * Returns the minimum character-axis offset relative to the controller.
     *
     * @return inclusive minimum character-axis offset
     */
    public int getMinX() {
        return -centerOffset.x();
    }

    /**
     * Returns the minimum string-axis offset relative to the controller.
     *
     * @return inclusive minimum string-axis offset
     */
    public int getMinY() {
        return -centerOffset.y();
    }

    /**
     * Returns the minimum aisle-axis offset for the maximum repeat envelope.
     *
     * @return inclusive minimum aisle-axis offset when all units use their maximum repeat count
     */
    public int getMinZ() {
        return -centerOffset.maxZ();
    }

    /** @return immutable structural layout metadata */
    public PatternLayout getLayout() {
        return layout;
    }

    /**
     * Returns the predicate at an unexpanded source coordinate in z/y/x order.
     *
     * @param z source aisle index
     * @param y row index
     * @param x character index
     * @return assigned predicate
     */
    public TraceabilityPredicate getPredicate(int z, int y, int x) {
        validatePatternCoordinates(z, y, x);
        return blockMatches[z][y][x];
    }

    /**
     * Maps pattern-axis offsets to an oriented controller-relative position.
     *
     * @param xOffset       character-axis offset
     * @param yOffset       string-axis offset
     * @param zOffset       aisle-axis offset
     * @param frontFacing   controller front
     * @param upwardsFacing controller upwards orientation
     * @param isFlipped     whether the pattern is mirrored
     * @return oriented relative position
     */
    public BlockPos getActualRelativeOffset(int xOffset, int yOffset, int zOffset, Direction frontFacing,
                                            Direction upwardsFacing, boolean isFlipped) {
        return offset(BlockPos.ZERO, frontFacing, upwardsFacing, isFlipped, yOffset, xOffset, zOffset);
    }

    private MatchAttempt tryMatchUnit(MultiblockState state, BlockPos centerPos, Direction frontFacing,
                                      Direction upwardsFacing, boolean isFlipped, int unitIndex, int forwardStart,
                                      MatchBudget budget) {
        int start = sourceStarts[unitIndex];
        int depth = sourceDepths[unitIndex];
        MultiblockState.Snapshot snapshot = state.snapshot();
        for (int inner = 0; inner < depth; inner++) {
            int z = start + inner;
            state.getLayerCount().clear();
            state.getStructureLayerCount().clear();
            BlockPos lastTarget = null;
            for (int y = 0; y < thumbLength; y++) {
                for (int x = 0; x < palmLength; x++) {
                    int leftOffset = x - centerOffset.x();
                    int upOffset = y - centerOffset.y();
                    int forwardOffset = forwardStart + inner;
                    BlockPos target = offset(centerPos, frontFacing, upwardsFacing, isFlipped, upOffset, leftOffset,
                            forwardOffset);
                    lastTarget = target;
                    if (!budget.visit()) {
                        state.restore(snapshot);
                        return MatchAttempt.failed(PatternDiagnostic.of("match_budget",
                                "Pattern matching exceeded the configured cell visit budget", target, List.of()));
                    }
                    TraceabilityPredicate predicate = blockMatches[z][y][x];
                    if (!state.update(target, predicate)) {
                        return failedTrial(state, snapshot, target);
                    }
                    if (!predicate.test(state)) {
                        return failedTrial(state, snapshot, target);
                    }
                    if (predicate.addCache()) {
                        state.addMatchedPosition(target);
                    }
                }
            }
            if (lastTarget == null) {
                state.restore(snapshot);
                throw new IllegalStateException("Cannot check layer minimums for empty structure slice " + z);
            }
            for (TraceabilityPredicate predicate : predicatesForSlice(z)) {
                if (!predicate.checkLayerMinimums(state)) {
                    return failedTrial(state, snapshot, lastTarget);
                }
            }
        }
        return MatchAttempt.matched();
    }

    private List<TraceabilityPredicate> predicatesForSlice(int z) {
        Set<TraceabilityPredicate> slicePredicates = new LinkedHashSet<>();
        for (int y = 0; y < thumbLength; y++) {
            for (int x = 0; x < palmLength; x++) {
                slicePredicates.add(blockMatches[z][y][x]);
            }
        }
        return List.copyOf(slicePredicates);
    }

    private MatchAttempt failedTrial(MultiblockState state, MultiblockState.Snapshot snapshot, BlockPos target) {
        PatternDiagnostic diagnostic = state.getDiagnostic();
        if (diagnostic == null) {
            TraceabilityPredicate predicate = state.getPredicate();
            state.restore(snapshot);
            throw new IllegalStateException("Structure predicate failed without diagnostic at " + target +
                    " for predicate " + predicate);
        }
        state.restore(snapshot);
        return MatchAttempt.failed(diagnostic);
    }

    private BlockPos offset(BlockPos centerPos, Direction frontFacing, Direction upwardsFacing, boolean isFlipped,
                            int upOffset, int leftOffset, int forwardOffset) {
        int actualUp = projectUpOffset(structureDir.stringDir(), upOffset) +
                projectUpOffset(structureDir.charDir(), leftOffset) +
                projectUpOffset(structureDir.aisleDir(), forwardOffset);
        int actualLeft = projectLeftOffset(structureDir.stringDir(), upOffset) +
                projectLeftOffset(structureDir.charDir(), leftOffset) +
                projectLeftOffset(structureDir.aisleDir(), forwardOffset);
        int actualForward = projectForwardOffset(structureDir.stringDir(), upOffset) +
                projectForwardOffset(structureDir.charDir(), leftOffset) +
                projectForwardOffset(structureDir.aisleDir(), forwardOffset);
        return RelativeDirection.offsetPos(centerPos, frontFacing, upwardsFacing, isFlipped, actualUp, actualLeft,
                actualForward);
    }

    private static int projectUpOffset(RelativeDirection direction, int offset) {
        return switch (direction) {
            case UP -> offset;
            case DOWN -> -offset;
            default -> 0;
        };
    }

    private static int projectLeftOffset(RelativeDirection direction, int offset) {
        return switch (direction) {
            case LEFT -> offset;
            case RIGHT -> -offset;
            default -> 0;
        };
    }

    private static int projectForwardOffset(RelativeDirection direction, int offset) {
        return switch (direction) {
            case FRONT -> offset;
            case BACK -> -offset;
            default -> 0;
        };
    }

    private void validateShape() {
        if (fingerLength != blockMatches.length) {
            throw new IllegalArgumentException("fingerLength does not match predicate depth");
        }
        if (repeatRanges.length != sourceStarts.length || sourceStarts.length != sourceDepths.length) {
            throw new IllegalArgumentException("Unit metadata arrays must have the same length");
        }
        for (int index = 0; index < repeatRanges.length; index++) {
            if (repeatRanges[index].length != 2) {
                throw new IllegalArgumentException("Repeat metadata at index " + index + " must contain min and max");
            }
        }
        for (int z = 0; z < blockMatches.length; z++) {
            if (blockMatches[z].length != thumbLength) {
                throw new IllegalArgumentException("Predicate slice " + z + " has invalid height");
            }
            for (int y = 0; y < blockMatches[z].length; y++) {
                if (blockMatches[z][y].length != palmLength) {
                    throw new IllegalArgumentException("Predicate row " + z + "/" + y + " has invalid width");
                }
            }
        }
    }

    private void validateMaximumSize() {
        long maximumLayers = 0;
        for (int index = 0; index < repeatRanges.length; index++) {
            maximumLayers = Math.addExact(maximumLayers,
                    Math.multiplyExact((long) sourceDepths[index], repeatRanges[index][1]));
        }
        long cellsPerLayer = Math.multiplyExact((long) palmLength, thumbLength);
        long maximumCells = Math.multiplyExact(maximumLayers, cellsPerLayer);
        if (maximumCells > MAX_PATTERN_CELLS) {
            throw new IllegalArgumentException(
                    "Pattern maximum cell count " + maximumCells + " exceeds limit " + MAX_PATTERN_CELLS);
        }
    }

    private static TraceabilityPredicate[][][] copyPredicates(TraceabilityPredicate[][][] predicates) {
        if (predicates == null || predicates.length == 0) {
            throw new IllegalArgumentException("Pattern must contain at least one aisle");
        }
        TraceabilityPredicate[][][] copy = new TraceabilityPredicate[predicates.length][][];
        for (int z = 0; z < predicates.length; z++) {
            TraceabilityPredicate[][] sourceSlice = predicates[z];
            copy[z] = new TraceabilityPredicate[sourceSlice.length][];
            for (int y = 0; y < sourceSlice.length; y++) {
                copy[z][y] = Arrays.copyOf(sourceSlice[y], sourceSlice[y].length);
            }
        }
        return copy;
    }

    private void validatePatternCoordinates(int z, int y, int x) {
        if (z < 0 || z >= fingerLength) {
            throw new IndexOutOfBoundsException("Pattern z coordinate " + z + " outside [0, " + fingerLength + ")");
        }
        if (y < 0 || y >= thumbLength) {
            throw new IndexOutOfBoundsException("Pattern y coordinate " + y + " outside [0, " + thumbLength + ")");
        }
        if (x < 0 || x >= palmLength) {
            throw new IndexOutOfBoundsException("Pattern x coordinate " + x + " outside [0, " + palmLength + ")");
        }
    }

    int unitCount() {
        return sourceStarts.length;
    }

    int unitStart(int index) {
        return sourceStarts[index];
    }

    int unitDepth(int index) {
        return sourceDepths[index];
    }

    RepeatRange unitRepeatRange(int index) {
        return new RepeatRange(repeatRanges[index][0], repeatRanges[index][1]);
    }

    private static int[][] copy2d(int[][] source) {
        int[][] copy = new int[source.length][];
        for (int i = 0; i < source.length; i++) {
            copy[i] = Arrays.copyOf(source[i], source[i].length);
        }
        return copy;
    }

    private static String[][] copySlices(String[][] source) {
        String[][] copy = new String[source.length][];
        for (int i = 0; i < source.length; i++) {
            copy[i] = Arrays.copyOf(source[i], source[i].length);
        }
        return copy;
    }

    private record MatchAttempt(boolean success, PatternDiagnostic diagnostic) {

        public static MatchAttempt matched() {
            return new MatchAttempt(true, null);
        }

        public static MatchAttempt failed(PatternDiagnostic diagnostic) {
            return new MatchAttempt(false, diagnostic);
        }
    }

    private static final class MatchBudget {

        private final int limit;
        private int visited;
        private boolean exceeded;

        private MatchBudget(int limit) {
            if (limit <= 0) {
                throw new IllegalArgumentException("Pattern match cell visit budget must be positive");
            }
            this.limit = limit;
        }

        private boolean visit() {
            if (visited >= limit) {
                exceeded = true;
                return false;
            }
            visited++;
            return true;
        }

        private boolean exceeded() {
            return exceeded;
        }
    }
}
