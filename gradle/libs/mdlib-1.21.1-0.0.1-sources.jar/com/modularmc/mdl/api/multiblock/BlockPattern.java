package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.api.multiblock.util.RelativeDirection;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Immutable multiblock pattern made from aisle slices and traceability predicates.
 */
public class BlockPattern {

    public final int[][] aisleRepetitions;
    public final int[] unitStarts;
    public final int[] unitDepths;
    public final StructureDir structureDir;
    public final String[][] structureSlices;
    private final TraceabilityPredicate[][][] blockMatches;
    private final int fingerLength;
    private final int thumbLength;
    private final int palmLength;
    private final CenterOffset centerOffset;
    private final Collection<TraceabilityPredicate> predicates;
    public PatternCondition condition;

    public BlockPattern(TraceabilityPredicate[][][] predicates, StructureDir structureDir, int[][] aisleRepetitions,
                        int[] unitStarts, int[] unitDepths, String[][] structureSlices, CenterOffset centerOffset,
                        int fingerLength, int thumbLength, int palmLength,
                        Collection<TraceabilityPredicate> symbolPredicates) {
        this.blockMatches = requirePredicates(predicates);
        this.structureDir = Objects.requireNonNull(structureDir, "structureDir");
        this.aisleRepetitions = copy2d(aisleRepetitions);
        this.unitStarts = Arrays.copyOf(unitStarts, unitStarts.length);
        this.unitDepths = Arrays.copyOf(unitDepths, unitDepths.length);
        this.structureSlices = copySlices(structureSlices);
        this.centerOffset = Objects.requireNonNull(centerOffset, "centerOffset");
        this.fingerLength = fingerLength;
        this.thumbLength = thumbLength;
        this.palmLength = palmLength;
        this.predicates = List.copyOf(symbolPredicates);
        validateShape();
    }

    public StructureMatchResult checkPatternAt(StructureWorldView world, StructureControllerView controller,
                                               String structureName) {
        Objects.requireNonNull(controller, "controller");
        MultiblockState state = new MultiblockState(world, controller.position(), structureName);
        StructureMatchResult result = checkPatternAt(state, controller.position(), controller.frontFacing(),
                controller.upwardsFacing(), false);
        if (!result.matched() && controller.allowFlip()) {
            result = checkPatternAt(state, controller.position(), controller.frontFacing(), controller.upwardsFacing(),
                    true);
        }
        return result;
    }

    public StructureMatchResult checkPatternAt(MultiblockState state, BlockPos centerPos, Direction frontFacing,
                                               Direction upwardsFacing, boolean isFlipped) {
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(centerPos, "centerPos");
        Objects.requireNonNull(frontFacing, "frontFacing");
        Objects.requireNonNull(upwardsFacing, "upwardsFacing");
        state.clean();
        PatternDiagnostic lastDiagnostic = null;
        boolean foundFirstAisle = false;
        int firstAisleSearchStart = -centerOffset.maxZ();
        int forward = firstAisleSearchStart++;
        for (int unitIndex = 0; unitIndex < aisleRepetitions.length; unitIndex++) {
            int minRepeat = aisleRepetitions[unitIndex][0];
            int maxRepeat = aisleRepetitions[unitIndex][1];
            int matchedRepeat = 0;
            for (int repeat = 0; foundFirstAisle ? repeat < maxRepeat : forward <= -centerOffset.minZ(); repeat++) {
                int repeatStartForward = forward;
                MatchAttempt attempt = tryMatchUnit(state, centerPos, frontFacing, upwardsFacing, isFlipped, unitIndex,
                        forward);
                if (!attempt.success()) {
                    lastDiagnostic = attempt.diagnostic();
                    if (foundFirstAisle) {
                        if (matchedRepeat < minRepeat) {
                            unitIndex = -1;
                            foundFirstAisle = false;
                            forward = firstAisleSearchStart++;
                            state.clean();
                            break;
                        }
                        forward = repeatStartForward;
                        break;
                    }
                    forward = repeatStartForward + 1;
                    continue;
                }
                foundFirstAisle = true;
                matchedRepeat++;
                forward += unitDepths[unitIndex];
            }
            if (unitIndex == -1) {
                continue;
            }
            if (!foundFirstAisle || matchedRepeat < minRepeat) {
                return StructureMatchResult.failure(frontFacing, state.getMatchContext(),
                        failedSearchDiagnostic(centerPos, lastDiagnostic));
            }
        }

        for (TraceabilityPredicate predicate : predicates) {
            if (!predicate.checkGlobalMinimums(state)) {
                return StructureMatchResult.failure(frontFacing, state.getMatchContext(), state.getDiagnostic());
            }
        }
        if (condition != null && !condition.condition().test(state)) {
            return StructureMatchResult.failure(frontFacing, state.getMatchContext(),
                    PatternDiagnostic.of("condition", "Pattern condition failed: " + condition.translationKey(),
                            centerPos, List.of()));
        }
        return StructureMatchResult.success(isFlipped, frontFacing, state.getMatchedPositions(),
                state.getMatchContext());
    }

    private PatternDiagnostic failedSearchDiagnostic(BlockPos centerPos, PatternDiagnostic lastDiagnostic) {
        if (lastDiagnostic != null) {
            return lastDiagnostic;
        }
        return PatternDiagnostic.of("pattern_mismatch", "Structure pattern did not match", centerPos, List.of());
    }

    public int[] getDimensions() {
        return new int[] { fingerLength, thumbLength, palmLength };
    }

    public CenterOffset getCenterOffset() {
        return centerOffset;
    }

    public int getFingerLength() {
        return fingerLength;
    }

    public int getThumbLength() {
        return thumbLength;
    }

    public int getPalmLength() {
        return palmLength;
    }

    public int getMinX() {
        return -centerOffset.x();
    }

    public int getMinY() {
        return -centerOffset.y();
    }

    public int getMinZ() {
        return -centerOffset.maxZ();
    }

    /**
     * Returns the predicate stored at an unexpanded pattern coordinate in z/y/x order.
     */
    public TraceabilityPredicate getPredicate(int z, int y, int x) {
        validatePatternCoordinates(z, y, x);
        return blockMatches[z][y][x];
    }

    /**
     * Maps a center-relative pattern offset to an oriented offset from the controller position.
     */
    public BlockPos getActualRelativeOffset(int xOffset, int yOffset, int zOffset, Direction frontFacing,
                                            Direction upwardsFacing, boolean isFlipped) {
        return offset(BlockPos.ZERO, frontFacing, upwardsFacing, isFlipped, yOffset, xOffset, zOffset);
    }

    private MatchAttempt tryMatchUnit(MultiblockState state, BlockPos centerPos, Direction frontFacing,
                                      Direction upwardsFacing, boolean isFlipped, int unitIndex, int forwardStart) {
        int start = unitStarts[unitIndex];
        int depth = unitDepths[unitIndex];
        MultiblockState.Snapshot snapshot = state.snapshot();
        for (int inner = 0; inner < depth; inner++) {
            int z = start + inner;
            state.getLayerCount().clear();
            state.getStructureLayerCount().clear();
            BlockPos lastTarget = null;
            for (int y = 0; y < thumbLength; y++) {
                for (int x = 0; x < palmLength; x++) {
                    int leftOffset = x - centerOffset.x();
                    int upOffset = y - centerOffset.y();
                    int forwardOffset = forwardStart + inner;
                    BlockPos target = offset(centerPos, frontFacing, upwardsFacing, isFlipped, upOffset, leftOffset,
                            forwardOffset);
                    lastTarget = target;
                    TraceabilityPredicate predicate = blockMatches[z][y][x];
                    if (!state.update(target, predicate)) {
                        return failedTrial(state, snapshot, target);
                    }
                    if (!predicate.test(state)) {
                        return failedTrial(state, snapshot, target);
                    }
                    if (predicate.addCache()) {
                        state.addMatchedPosition(target);
                    }
                }
            }
            if (lastTarget == null) {
                state.restore(snapshot);
                throw new IllegalStateException("Cannot check layer minimums for empty structure slice " + z);
            }
            for (TraceabilityPredicate predicate : predicatesForSlice(z)) {
                if (!predicate.checkLayerMinimums(state)) {
                    return failedTrial(state, snapshot, lastTarget);
                }
            }
        }
        return MatchAttempt.matched();
    }

    private List<TraceabilityPredicate> predicatesForSlice(int z) {
        Set<TraceabilityPredicate> slicePredicates = new LinkedHashSet<>();
        for (int y = 0; y < thumbLength; y++) {
            for (int x = 0; x < palmLength; x++) {
                slicePredicates.add(blockMatches[z][y][x]);
            }
        }
        return List.copyOf(slicePredicates);
    }

    private MatchAttempt failedTrial(MultiblockState state, MultiblockState.Snapshot snapshot, BlockPos target) {
        PatternDiagnostic diagnostic = state.getDiagnostic();
        if (diagnostic == null) {
            TraceabilityPredicate predicate = state.getPredicate();
            state.restore(snapshot);
            throw new IllegalStateException("Structure predicate failed without diagnostic at " + target +
                    " for predicate " + predicate);
        }
        state.restore(snapshot);
        return MatchAttempt.failed(diagnostic);
    }

    private BlockPos offset(BlockPos centerPos, Direction frontFacing, Direction upwardsFacing, boolean isFlipped,
                            int upOffset, int leftOffset, int forwardOffset) {
        int actualUp = projectUpOffset(structureDir.stringDir(), upOffset) +
                projectUpOffset(structureDir.charDir(), leftOffset) +
                projectUpOffset(structureDir.aisleDir(), forwardOffset);
        int actualLeft = projectLeftOffset(structureDir.stringDir(), upOffset) +
                projectLeftOffset(structureDir.charDir(), leftOffset) +
                projectLeftOffset(structureDir.aisleDir(), forwardOffset);
        int actualForward = projectForwardOffset(structureDir.stringDir(), upOffset) +
                projectForwardOffset(structureDir.charDir(), leftOffset) +
                projectForwardOffset(structureDir.aisleDir(), forwardOffset);
        return RelativeDirection.offsetPos(centerPos, frontFacing, upwardsFacing, isFlipped, actualUp, actualLeft,
                actualForward);
    }

    private static int projectUpOffset(RelativeDirection direction, int offset) {
        return switch (direction) {
            case UP -> offset;
            case DOWN -> -offset;
            default -> 0;
        };
    }

    private static int projectLeftOffset(RelativeDirection direction, int offset) {
        return switch (direction) {
            case LEFT -> offset;
            case RIGHT -> -offset;
            default -> 0;
        };
    }

    private static int projectForwardOffset(RelativeDirection direction, int offset) {
        return switch (direction) {
            case FRONT -> offset;
            case BACK -> -offset;
            default -> 0;
        };
    }

    private void validateShape() {
        if (fingerLength != blockMatches.length) {
            throw new IllegalArgumentException("fingerLength does not match predicate depth");
        }
        if (aisleRepetitions.length != unitStarts.length || unitStarts.length != unitDepths.length) {
            throw new IllegalArgumentException("Unit metadata arrays must have the same length");
        }
        for (int z = 0; z < blockMatches.length; z++) {
            if (blockMatches[z].length != thumbLength) {
                throw new IllegalArgumentException("Predicate slice " + z + " has invalid height");
            }
            for (int y = 0; y < blockMatches[z].length; y++) {
                if (blockMatches[z][y].length != palmLength) {
                    throw new IllegalArgumentException("Predicate row " + z + "/" + y + " has invalid width");
                }
            }
        }
    }

    private void validatePatternCoordinates(int z, int y, int x) {
        if (z < 0 || z >= fingerLength) {
            throw new IndexOutOfBoundsException("Pattern z coordinate " + z + " outside [0, " + fingerLength + ")");
        }
        if (y < 0 || y >= thumbLength) {
            throw new IndexOutOfBoundsException("Pattern y coordinate " + y + " outside [0, " + thumbLength + ")");
        }
        if (x < 0 || x >= palmLength) {
            throw new IndexOutOfBoundsException("Pattern x coordinate " + x + " outside [0, " + palmLength + ")");
        }
    }

    private static TraceabilityPredicate[][][] requirePredicates(TraceabilityPredicate[][][] predicates) {
        if (predicates == null || predicates.length == 0) {
            throw new IllegalArgumentException("Pattern must contain at least one aisle");
        }
        return predicates;
    }

    private static int[][] copy2d(int[][] source) {
        int[][] copy = new int[source.length][];
        for (int i = 0; i < source.length; i++) {
            copy[i] = Arrays.copyOf(source[i], source[i].length);
        }
        return copy;
    }

    private static String[][] copySlices(String[][] source) {
        String[][] copy = new String[source.length][];
        for (int i = 0; i < source.length; i++) {
            copy[i] = Arrays.copyOf(source[i], source[i].length);
        }
        return copy;
    }

    private record MatchAttempt(boolean success, PatternDiagnostic diagnostic) {

        public static MatchAttempt matched() {
            return new MatchAttempt(true, null);
        }

        public static MatchAttempt failed(PatternDiagnostic diagnostic) {
            return new MatchAttempt(false, Objects.requireNonNull(diagnostic, "diagnostic"));
        }
    }
}
