package com.modularmc.mdl.api.multiblock.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.util.StringRepresentable;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Locale;
import java.util.function.UnaryOperator;

/**
 * Direction relative to a structure controller's front and upwards directions.
 */
public enum RelativeDirection implements StringRepresentable {

    UP(dir -> dir.getAxis() == Direction.Axis.Y ? Direction.NORTH : Direction.UP, Direction.UP),
    DOWN(dir -> dir.getAxis() == Direction.Axis.Y ? Direction.SOUTH : Direction.DOWN, Direction.DOWN),
    LEFT(dir -> {
        if (dir == Direction.UP) return Direction.EAST;
        if (dir == Direction.DOWN) return Direction.WEST;
        return dir.getCounterClockWise();
    }, Direction.WEST),
    RIGHT(dir -> {
        if (dir == Direction.UP) return Direction.WEST;
        if (dir == Direction.DOWN) return Direction.EAST;
        return dir.getClockWise();
    }, Direction.EAST),
    FRONT(UnaryOperator.identity(), Direction.NORTH),
    BACK(Direction::getOpposite, Direction.SOUTH);

    private static final RelativeDirection[] BY_GLOBAL_DIRECTION = new RelativeDirection[Direction.values().length];

    static {
        for (RelativeDirection relative : values()) {
            BY_GLOBAL_DIRECTION[relative.global.ordinal()] = relative;
        }
    }

    private final UnaryOperator<Direction> actualDirection;
    public final Direction global;

    RelativeDirection(UnaryOperator<Direction> actualDirection, Direction global) {
        this.actualDirection = actualDirection;
        this.global = global;
    }

    @Override
    public @NotNull String getSerializedName() {
        return name().toLowerCase(Locale.ROOT);
    }

    public RelativeDirection getOpposite() {
        return switch (this) {
            case UP -> DOWN;
            case DOWN -> UP;
            case LEFT -> RIGHT;
            case RIGHT -> LEFT;
            case FRONT -> BACK;
            case BACK -> FRONT;
        };
    }

    public Direction getActualDirection(Direction direction) {
        return actualDirection.apply(direction);
    }

    public boolean isSameAxis(RelativeDirection other) {
        return this.global.getAxis() == other.global.getAxis();
    }

    public Vec3i applyVec3i(Direction facing) {
        return getActualDirection(facing).getNormal();
    }

    public Direction getRelative(Direction frontDir, Direction upwardsDir, boolean isFlipped) {
        Direction.Axis frontAxis = frontDir.getAxis();
        return switch (this) {
            case UP -> {
                if (frontAxis == Direction.Axis.Y) {
                    yield upwardsDir;
                }
                yield switch (upwardsDir) {
                    case NORTH -> Direction.UP;
                    case SOUTH -> Direction.DOWN;
                    case EAST -> frontDir.getCounterClockWise();
                    default -> frontDir.getClockWise();
                };
            }
            case DOWN -> {
                if (frontAxis == Direction.Axis.Y) {
                    yield upwardsDir.getOpposite();
                }
                yield switch (upwardsDir) {
                    case NORTH -> Direction.DOWN;
                    case SOUTH -> Direction.UP;
                    case EAST -> frontDir.getClockWise();
                    default -> frontDir.getCounterClockWise();
                };
            }
            case LEFT -> {
                Direction direction;
                if (frontAxis == Direction.Axis.Y) {
                    direction = frontDir.getStepY() > 0 ? upwardsDir.getClockWise() : upwardsDir.getCounterClockWise();
                } else {
                    direction = switch (upwardsDir) {
                        case NORTH -> frontDir.getCounterClockWise();
                        case SOUTH -> frontDir.getClockWise();
                        case EAST -> Direction.DOWN;
                        default -> Direction.UP;
                    };
                }
                yield isFlipped ? direction.getOpposite() : direction;
            }
            case RIGHT -> {
                Direction direction;
                if (frontAxis == Direction.Axis.Y) {
                    direction = frontDir.getStepY() > 0 ? upwardsDir.getCounterClockWise() : upwardsDir.getClockWise();
                } else {
                    direction = switch (upwardsDir) {
                        case NORTH -> frontDir.getClockWise();
                        case SOUTH -> frontDir.getCounterClockWise();
                        case EAST -> Direction.UP;
                        default -> Direction.DOWN;
                    };
                }
                yield isFlipped ? direction.getOpposite() : direction;
            }
            case FRONT -> frontDir;
            case BACK -> frontDir.getOpposite();
        };
    }

    public Comparator<BlockPos> getSorter(Direction frontDir, Direction upwardsDir, boolean isFlipped) {
        Direction sorterDirection = getRelative(frontDir, upwardsDir, isFlipped);
        return switch (sorterDirection) {
            case UP -> Comparator.comparingInt(BlockPos::getY);
            case DOWN -> Comparator.comparingInt(pos -> -pos.getY());
            case NORTH -> Comparator.comparingInt(pos -> -pos.getZ());
            case EAST -> Comparator.comparingInt(BlockPos::getX);
            case SOUTH -> Comparator.comparingInt(BlockPos::getZ);
            case WEST -> Comparator.comparingInt(pos -> -pos.getX());
        };
    }

    public static BlockPos offsetPos(BlockPos pos, Direction frontDir, Direction upwardsDir, boolean isFlipped,
                                     int upOffset, int leftOffset, int forwardOffset) {
        if (upOffset == 0 && leftOffset == 0 && forwardOffset == 0) {
            return pos;
        }
        int x = 0;
        int y = 0;
        int z = 0;
        Direction up = UP.getRelative(frontDir, upwardsDir, isFlipped);
        x += up.getStepX() * upOffset;
        y += up.getStepY() * upOffset;
        z += up.getStepZ() * upOffset;
        Direction left = LEFT.getRelative(frontDir, upwardsDir, isFlipped);
        x += left.getStepX() * leftOffset;
        y += left.getStepY() * leftOffset;
        z += left.getStepZ() * leftOffset;
        Direction front = FRONT.getRelative(frontDir, upwardsDir, isFlipped);
        x += front.getStepX() * forwardOffset;
        y += front.getStepY() * forwardOffset;
        z += front.getStepZ() * forwardOffset;
        return pos.offset(x, y, z);
    }

    public static RelativeDirection fromGlobalDirection(Direction direction) {
        RelativeDirection relative = BY_GLOBAL_DIRECTION[direction.ordinal()];
        if (relative == null) {
            throw new IllegalArgumentException("No relative direction for " + direction);
        }
        return relative;
    }
}
