package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.MDLib;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import java.util.List;
import java.util.Objects;

/**
 * Structured failure details produced by a structure match attempt.
 */
public record PatternDiagnostic(ResourceLocation code, String message, BlockPos position, List<String> expected) {

    public static PatternDiagnostic of(String code, String message, BlockPos position, List<String> expected) {
        return new PatternDiagnostic(MDLib.id(code), message, position, expected);
    }

    public PatternDiagnostic {
        Objects.requireNonNull(code, "code");
        if (message == null || message.isBlank()) {
            throw new IllegalArgumentException("Pattern diagnostic message cannot be blank");
        }
        expected = expected == null ? List.of() : List.copyOf(expected);
    }
}
