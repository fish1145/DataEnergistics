package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import java.util.List;
import java.util.Objects;

/**
 * Structured failure details produced by a structure match attempt.
 */
public record PatternDiagnostic(ResourceLocation code, String message, BlockPos position, List<String> expected) {

    private static final String DEFAULT_NAMESPACE = "mdlib";

    public static PatternDiagnostic of(String code, String message, BlockPos position, List<String> expected) {
        return new PatternDiagnostic(readCode(code), message, position, expected);
    }

    public PatternDiagnostic {
        Objects.requireNonNull(code, "code");
        if (message == null || message.isBlank()) {
            throw new IllegalArgumentException("Pattern diagnostic message cannot be blank");
        }
        expected = expected == null ? List.of() : List.copyOf(expected);
    }

    private static ResourceLocation readCode(String code) {
        if (code == null || code.isBlank()) {
            throw new IllegalArgumentException("Pattern diagnostic code cannot be blank");
        }
        if (code.indexOf(':') > 0) {
            return ResourceLocation.parse(code);
        }
        if (code.charAt(0) == ':') {
            code = code.substring(1);
        }
        return ResourceLocation.fromNamespaceAndPath(DEFAULT_NAMESPACE, code);
    }
}
