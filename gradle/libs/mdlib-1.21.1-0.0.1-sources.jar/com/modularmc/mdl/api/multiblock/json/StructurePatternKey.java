package com.modularmc.mdl.api.multiblock.json;

import net.minecraft.resources.ResourceLocation;

import java.util.Objects;

/**
 * Identifies one named structure pattern owned by a mod object.
 */
public record StructurePatternKey(ResourceLocation ownerId, String structureName) {

    public static final String DEFAULT_STRUCTURE_NAME = "main";

    public StructurePatternKey {
        Objects.requireNonNull(ownerId, "ownerId");
        if (structureName == null || structureName.isBlank()) {
            throw new IllegalArgumentException("Structure name cannot be blank for " + ownerId);
        }
        if (structureName.indexOf('/') >= 0 || structureName.indexOf('\\') >= 0) {
            throw new IllegalArgumentException("Structure name must be one path segment: " + structureName);
        }
    }

    public static StructurePatternKey main(ResourceLocation ownerId) {
        return new StructurePatternKey(ownerId, DEFAULT_STRUCTURE_NAME);
    }

    public boolean isDefaultStructure() {
        return DEFAULT_STRUCTURE_NAME.equals(structureName);
    }

    public ResourceLocation resourceId() {
        if (isDefaultStructure()) {
            return ownerId;
        }
        return ownerId.withPath(path -> path + "/" + structureName);
    }
}
