package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternCandidate;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import com.google.gson.JsonObject;

import java.util.List;
import java.util.Objects;

/**
 * Wraps another predicate with global and layer count limits.
 */
public record RestrictedPredicate(StructurePredicate delegate, int minGlobal, int maxGlobal, int minLayer,
                                  int maxLayer)
        implements StructurePredicate {

    public RestrictedPredicate {
        Objects.requireNonNull(delegate, "delegate");
        validate(minGlobal, maxGlobal, "global");
        validate(minLayer, maxLayer, "layer");
    }

    public static RestrictedPredicate fromJson(JsonObject object) {
        StructurePredicate delegate = StructurePredicateTypes.decode(JsonHelpers.requiredObject(object, "predicate"));
        int minGlobal = JsonHelpers.optionalInt(object, "minCount", "min", -1);
        int maxGlobal = JsonHelpers.optionalInt(object, "maxCount", "max", -1);
        int minLayer = JsonHelpers.optionalInt(object, "minCountByLayer", "min_layer", -1);
        int maxLayer = JsonHelpers.optionalInt(object, "maxCountByLayer", "max_layer", -1);
        return new RestrictedPredicate(delegate, minGlobal, maxGlobal, minLayer, maxLayer);
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.RESTRICTED;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        boolean matched = delegate.test(state, mutateCount);
        if (!matched) return false;
        if (!mutateCount) return true;
        int global = state.getStructureGlobalCount().mergeInt(this, 1, Integer::sum);
        int layer = state.getStructureLayerCount().mergeInt(this, 1, Integer::sum);
        if (maxGlobal >= 0 && global > maxGlobal) {
            state.setDiagnostic(PatternDiagnostic.of("restricted_global", "Predicate exceeded global limit",
                    state.getPos(), List.of()));
            return false;
        }
        if (maxLayer >= 0 && layer > maxLayer) {
            state.setDiagnostic(PatternDiagnostic.of("restricted_layer", "Predicate exceeded layer limit",
                    state.getPos(), List.of()));
            return false;
        }
        return true;
    }

    @Override
    public boolean checkGlobalMinimum(MultiblockState state) {
        if (!delegate.checkGlobalMinimum(state)) {
            return false;
        }
        int global = state.getStructureGlobalCount().getInt(this);
        if (minGlobal >= 0 && global < minGlobal) {
            state.setDiagnostic(PatternDiagnostic.of("restricted_global_min",
                    "Predicate did not reach global minimum", state.getControllerPos(), expected()));
            return false;
        }
        return true;
    }

    @Override
    public boolean checkLayerMinimum(MultiblockState state) {
        if (!delegate.checkLayerMinimum(state)) {
            return false;
        }
        int layer = state.getStructureLayerCount().getInt(this);
        if (minLayer >= 0 && layer < minLayer) {
            state.setDiagnostic(PatternDiagnostic.of("restricted_layer_min",
                    "Predicate did not reach layer minimum", state.getPos(), expected()));
            return false;
        }
        return true;
    }

    @Override
    public List<Block> blockCandidates() {
        return delegate.blockCandidates();
    }

    @Override
    public List<BlockState> blockStateCandidates() {
        return delegate.blockStateCandidates();
    }

    @Override
    public List<ItemStack> placementCandidates() {
        return delegate.placementCandidates().stream().map(ItemStack::copy).toList();
    }

    @Override
    public List<PatternCandidate> patternCandidates() {
        return List.copyOf(delegate.patternCandidates());
    }

    @Override
    public boolean hasAir() {
        return delegate.hasAir();
    }

    public boolean satisfiesMinimums(int globalCount, int layerCount) {
        return (minGlobal < 0 || globalCount >= minGlobal) && (minLayer < 0 || layerCount >= minLayer);
    }

    private List<String> expected() {
        return blockCandidates().stream().map(block -> BuiltInRegistries.BLOCK.getKey(block).toString()).toList();
    }

    private static void validate(int min, int max, String label) {
        if (min < -1 || max < -1) {
            throw new IllegalArgumentException(label + " limits must be -1 or non-negative");
        }
        if (min >= 0 && max >= 0 && min > max) {
            throw new IllegalArgumentException(label + " minimum cannot exceed maximum");
        }
    }
}
