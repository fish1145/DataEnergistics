package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.List;

/**
 * Matches air blocks only.
 */
public enum AirPredicate implements StructurePredicate {

    INSTANCE;

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.AIR;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        return state.getBlockState().isAir();
    }

    @Override
    public List<Block> blockCandidates() {
        return List.of(Blocks.AIR);
    }

    @Override
    public boolean hasAir() {
        return true;
    }
}
