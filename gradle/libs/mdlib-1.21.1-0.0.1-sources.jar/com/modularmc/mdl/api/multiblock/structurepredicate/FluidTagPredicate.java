package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;

import com.google.gson.JsonObject;

import java.util.List;

/**
 * Matches fluid states in a fluid tag.
 */
public record FluidTagPredicate(TagKey<Fluid> tag) implements StructurePredicate {

    public static FluidTagPredicate fromJson(JsonObject object) {
        return new FluidTagPredicate(TagKey.create(Registries.FLUID,
                JsonHelpers.parseId(JsonHelpers.requiredString(object, "tag"), "fluid tag")));
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.FLUID_TAGS;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        boolean matched = state.getBlockState().getFluidState().is(tag);
        if (!matched) {
            state.setDiagnostic(PatternDiagnostic.of("fluid_tag_mismatch", "Fluid tag predicate did not match",
                    state.getPos(), List.of("#" + tag.location())));
        }
        return matched;
    }
}
