package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternCandidate;
import com.modularmc.mdl.api.multiblock.PatternDiagnostic;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Matches fluid states in a fluid tag.
 */
public record FluidTagPredicate(TagKey<Fluid> tag) implements StructurePredicate {

    public static FluidTagPredicate fromJson(JsonObject object) {
        return new FluidTagPredicate(TagKey.create(Registries.FLUID,
                JsonHelpers.parseId(JsonHelpers.requiredString(object, "tag"), "fluid tag")));
    }

    @Override
    public ResourceLocation type() {
        return StructurePredicateTypes.FLUID_TAGS;
    }

    @Override
    public boolean test(MultiblockState state, boolean mutateCount) {
        boolean matched = state.getBlockState().getFluidState().is(tag);
        if (!matched) {
            state.setDiagnostic(PatternDiagnostic.of("fluid_tag_mismatch", "Fluid tag predicate did not match",
                    state.getPos(), List.of("#" + tag.location())));
        }
        return matched;
    }

    @Override
    public List<BlockState> blockStateCandidates() {
        return taggedFluids().stream().map(fluid -> fluid.defaultFluidState().createLegacyBlock()).distinct().toList();
    }

    @Override
    public List<ItemStack> placementCandidates() {
        return taggedFluids().stream().map(Fluid::getBucket).distinct().map(Item::getDefaultInstance)
                .filter(stack -> !stack.isEmpty()).toList();
    }

    @Override
    public List<PatternCandidate> patternCandidates() {
        List<PatternCandidate> candidates = new ArrayList<>();
        for (Fluid fluid : taggedFluids()) {
            ItemStack stack = fluid.getBucket().getDefaultInstance();
            if (!stack.isEmpty()) {
                candidates.add(new PatternCandidate(fluid.defaultFluidState().createLegacyBlock(), stack));
            }
        }
        return List.copyOf(candidates);
    }

    private List<Fluid> taggedFluids() {
        return BuiltInRegistries.FLUID.getTag(tag)
                .map(holders -> holders.stream().map(holder -> holder.value()).toList())
                .orElseGet(List::of);
    }
}
