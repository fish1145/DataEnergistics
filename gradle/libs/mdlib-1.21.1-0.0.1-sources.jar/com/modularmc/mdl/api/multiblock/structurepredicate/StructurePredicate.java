package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;

import java.util.List;

/**
 * Predicate used by serialized and programmatic structure definitions.
 */
public interface StructurePredicate {

    ResourceLocation type();

    boolean test(MultiblockState state, boolean mutateCount);

    /**
     * Checks global minimum constraints after the full structure has matched.
     */
    default boolean checkGlobalMinimum(MultiblockState state) {
        return true;
    }

    /**
     * Checks layer minimum constraints after one structure slice has matched.
     */
    default boolean checkLayerMinimum(MultiblockState state) {
        return true;
    }

    default List<Block> blockCandidates() {
        return List.of();
    }

    default StructurePredicate or(StructurePredicate other) {
        return ConcatenatedPredicate.concat(this, other);
    }

    default boolean isAny() {
        return this instanceof AnyPredicate;
    }

    default boolean isAir() {
        return this instanceof AirPredicate;
    }

    default boolean hasAir() {
        return false;
    }

    default boolean addCache() {
        return !isAny();
    }
}
