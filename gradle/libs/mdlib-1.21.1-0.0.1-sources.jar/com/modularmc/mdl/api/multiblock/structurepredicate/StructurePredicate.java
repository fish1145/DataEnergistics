package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;
import com.modularmc.mdl.api.multiblock.PatternCandidate;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Predicate used by serialized and programmatic structure definitions.
 */
public interface StructurePredicate {

    ResourceLocation type();

    boolean test(MultiblockState state, boolean mutateCount);

    /**
     * Checks global minimum constraints after the full structure has matched.
     */
    default boolean checkGlobalMinimum(MultiblockState state) {
        return true;
    }

    /**
     * Checks layer minimum constraints after one structure slice has matched.
     */
    default boolean checkLayerMinimum(MultiblockState state) {
        return true;
    }

    default List<Block> blockCandidates() {
        return List.of();
    }

    /**
     * Exposes exact states for preview consumers while preserving state properties when an implementation has them.
     *
     * @return immutable candidate state list
     */
    default List<BlockState> blockStateCandidates() {
        return blockCandidates().stream().map(Block::defaultBlockState).distinct().toList();
    }

    /**
     * Exposes detached item stacks that can satisfy this predicate in a placement plan.
     *
     * @return immutable list whose mutable stacks are owned by the caller
     */
    default List<ItemStack> placementCandidates() {
        List<ItemStack> candidates = new ArrayList<>();
        Set<Item> seenItems = new LinkedHashSet<>();
        for (BlockState state : blockStateCandidates()) {
            Item item = state.getBlock().asItem();
            if (seenItems.add(item)) {
                ItemStack stack = item.getDefaultInstance();
                if (!stack.isEmpty()) {
                    candidates.add(stack);
                }
            }
        }
        return List.copyOf(candidates);
    }

    /**
     * Exposes authoritative preview-state and placement-stack pairs.
     * <p>
     * Legacy implementations with separate state and stack lists are accepted only when their relationship is
     * unambiguous. Implementations with custom many-to-many relationships must override this method and provide
     * explicit pairs.
     *
     * @return stable immutable candidate list
     */
    default List<PatternCandidate> patternCandidates() {
        List<BlockState> states = requireCandidateStates(blockStateCandidates());
        List<ItemStack> stacks = deduplicateCandidateStacks(placementCandidates());
        List<PatternCandidate> defaultCandidates = defaultPatternCandidates(states);
        if (sameCandidateStacks(defaultCandidates, stacks)) {
            return defaultCandidates;
        }
        if (states.isEmpty() || stacks.isEmpty()) {
            throw new IllegalStateException("Legacy structure predicate candidates must provide both preview states " +
                    "and placement stacks");
        }
        if (states.size() == 1) {
            return stacks.stream().map(stack -> new PatternCandidate(states.getFirst(), stack)).toList();
        }
        if (stacks.size() == 1) {
            return states.stream().map(state -> new PatternCandidate(state, stacks.getFirst())).toList();
        }
        throw new IllegalStateException("Legacy structure predicate candidates are ambiguous; override " +
                "patternCandidates() with explicit PatternCandidate pairs");
    }

    default StructurePredicate or(StructurePredicate other) {
        return ConcatenatedPredicate.concat(this, other);
    }

    default boolean isAny() {
        return this instanceof AnyPredicate;
    }

    default boolean isAir() {
        return this instanceof AirPredicate;
    }

    default boolean hasAir() {
        return false;
    }

    default boolean addCache() {
        return !isAny();
    }

    private static List<BlockState> requireCandidateStates(List<BlockState> states) {
        if (states == null) {
            throw new IllegalStateException("Structure predicate returned a null block state candidate list");
        }
        if (states.stream().anyMatch(state -> state == null)) {
            throw new IllegalStateException("Structure predicate returned a null block state candidate");
        }
        return states.stream().distinct().toList();
    }

    private static List<ItemStack> deduplicateCandidateStacks(List<ItemStack> stacks) {
        if (stacks == null) {
            throw new IllegalStateException("Structure predicate returned a null placement candidate list");
        }
        List<ItemStack> result = new ArrayList<>();
        for (ItemStack stack : stacks) {
            if (stack == null || stack.isEmpty()) {
                throw new IllegalStateException("Structure predicate returned a null or empty placement candidate");
            }
            if (result.stream().noneMatch(existing -> ItemStack.isSameItemSameComponents(existing, stack))) {
                result.add(stack.copy());
            }
        }
        return List.copyOf(result);
    }

    private static List<PatternCandidate> defaultPatternCandidates(List<BlockState> states) {
        List<PatternCandidate> result = new ArrayList<>();
        for (BlockState state : states) {
            ItemStack stack = state.getBlock().asItem().getDefaultInstance();
            if (stack.isEmpty()) {
                continue;
            }
            PatternCandidate candidate = new PatternCandidate(state, stack);
            boolean duplicate = result.stream()
                    .anyMatch(existing -> existing.previewState().equals(candidate.previewState()) &&
                            ItemStack.isSameItemSameComponents(
                                    existing.placementStack(), candidate.placementStack()));
            if (!duplicate) {
                result.add(candidate);
            }
        }
        return List.copyOf(result);
    }

    private static boolean sameCandidateStacks(List<PatternCandidate> candidates, List<ItemStack> stacks) {
        List<ItemStack> expectedStacks = deduplicateCandidateStacks(candidates.stream()
                .map(PatternCandidate::placementStack)
                .toList());
        if (expectedStacks.size() != stacks.size()) {
            return false;
        }
        return expectedStacks.stream().allMatch(expected -> stacks.stream().anyMatch(
                stack -> ItemStack.isSameItemSameComponents(expected, stack)));
    }
}
