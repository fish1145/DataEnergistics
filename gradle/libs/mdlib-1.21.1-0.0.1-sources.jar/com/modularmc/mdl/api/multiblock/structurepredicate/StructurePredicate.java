package com.modularmc.mdl.api.multiblock.structurepredicate;

import com.modularmc.mdl.api.multiblock.MultiblockState;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Predicate used by serialized and programmatic structure definitions.
 */
public interface StructurePredicate {

    ResourceLocation type();

    boolean test(MultiblockState state, boolean mutateCount);

    /**
     * Checks global minimum constraints after the full structure has matched.
     */
    default boolean checkGlobalMinimum(MultiblockState state) {
        return true;
    }

    /**
     * Checks layer minimum constraints after one structure slice has matched.
     */
    default boolean checkLayerMinimum(MultiblockState state) {
        return true;
    }

    default List<Block> blockCandidates() {
        return List.of();
    }

    /**
     * Exposes exact states for preview consumers while preserving state properties when an implementation has them.
     *
     * @return immutable candidate state list
     */
    default List<BlockState> blockStateCandidates() {
        return blockCandidates().stream().map(Block::defaultBlockState).distinct().toList();
    }

    /**
     * Exposes detached item stacks that can satisfy this predicate in a placement plan.
     *
     * @return immutable list whose mutable stacks are owned by the caller
     */
    default List<ItemStack> placementCandidates() {
        List<ItemStack> candidates = new ArrayList<>();
        Set<Item> seenItems = new LinkedHashSet<>();
        for (BlockState state : blockStateCandidates()) {
            Item item = state.getBlock().asItem();
            if (seenItems.add(item)) {
                ItemStack stack = item.getDefaultInstance();
                if (!stack.isEmpty()) {
                    candidates.add(stack);
                }
            }
        }
        return List.copyOf(candidates);
    }

    default StructurePredicate or(StructurePredicate other) {
        return ConcatenatedPredicate.concat(this, other);
    }

    default boolean isAny() {
        return this instanceof AnyPredicate;
    }

    default boolean isAir() {
        return this instanceof AirPredicate;
    }

    default boolean hasAir() {
        return false;
    }

    default boolean addCache() {
        return !isAny();
    }
}
