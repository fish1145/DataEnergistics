package com.modularmc.mdl.api.multiblock.json;

import com.modularmc.mdl.api.multiblock.BlockPattern;
import com.modularmc.mdl.api.multiblock.FactoryBlockPattern;
import com.modularmc.mdl.api.multiblock.TraceabilityPredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.StructurePredicate;
import com.modularmc.mdl.api.multiblock.structurepredicate.StructurePredicateTypes;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.Reader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Parses MDL/GregTech-style JSON string-array structure definitions.
 */
public final class StructurePatternResolver {

    private StructurePatternResolver() {}

    public static BlockPattern parsePattern(Reader reader) {
        return parseDefinition(reader).toPattern();
    }

    public static BlockPattern parsePattern(String json) {
        return parseDefinition(json).toPattern();
    }

    public static StringArrayDefinition parseDefinition(Reader reader) {
        return parseDefinition(JsonParser.parseReader(reader));
    }

    public static StringArrayDefinition parseDefinition(String json) {
        return parseDefinition(JsonParser.parseString(json));
    }

    public static StringArrayDefinition parseDefinition(JsonElement element) {
        if (!element.isJsonObject()) {
            throw new IllegalArgumentException("Json structure definition must be an object");
        }
        JsonObject object = element.getAsJsonObject();
        Map<Character, StructurePredicate> predicates = parsePredicates(object.get("predicates"));
        JsonElement aislesElement = object.get("aisles");
        if (aislesElement == null || !aislesElement.isJsonArray() || aislesElement.getAsJsonArray().isEmpty()) {
            throw new IllegalArgumentException("Json structure definition must define non-empty 'aisles'");
        }
        List<Unit> units = new ArrayList<>();
        for (JsonElement unitElement : aislesElement.getAsJsonArray()) {
            if (!unitElement.isJsonObject()) {
                throw new IllegalArgumentException("Json structure definition 'aisles' must contain repeat objects");
            }
            units.add(parseUnit(unitElement.getAsJsonObject()));
        }
        validateAisles(units.stream().flatMap(unit -> unit.slices().stream()).toList());
        return new StringArrayDefinition(List.copyOf(units), predicates);
    }

    private static Unit parseUnit(JsonObject object) {
        JsonElement slicesElement = object.get("slices");
        if (slicesElement == null || !slicesElement.isJsonArray() || slicesElement.getAsJsonArray().isEmpty()) {
            throw new IllegalArgumentException("Json repeat unit must contain non-empty 'slices'");
        }
        List<String[]> slices = new ArrayList<>();
        for (JsonElement sliceElement : slicesElement.getAsJsonArray()) {
            if (!sliceElement.isJsonArray()) {
                throw new IllegalArgumentException("Json repeat unit slices must be string arrays");
            }
            slices.add(parseSlice(sliceElement.getAsJsonArray()));
        }
        validateAisles(slices);

        int min = 1;
        int max = 1;
        JsonElement repeatElement = object.get("repeat");
        if (repeatElement != null) {
            if (!repeatElement.isJsonObject()) {
                throw new IllegalArgumentException("Json repeat field must be an object");
            }
            JsonObject repeat = repeatElement.getAsJsonObject();
            min = optionalInt(repeat, "min", min);
            max = optionalInt(repeat, "max", max);
        }
        if (min <= 0 || max <= 0 || min > max) {
            throw new IllegalArgumentException("Json repeat bounds must be positive and min <= max");
        }
        return new Unit(List.copyOf(slices), min, max);
    }

    private static String[] parseSlice(JsonArray array) {
        if (array.isEmpty()) {
            throw new IllegalArgumentException("Json structure slice cannot be empty");
        }
        String[] slice = new String[array.size()];
        for (int i = 0; i < array.size(); i++) {
            JsonElement row = array.get(i);
            if (!row.isJsonPrimitive() || !row.getAsJsonPrimitive().isString()) {
                throw new IllegalArgumentException("Json structure row " + i + " must be a string");
            }
            slice[i] = row.getAsString();
        }
        return slice;
    }

    private static int optionalInt(JsonObject object, String field, int fallback) {
        JsonElement element = object.get(field);
        if (element == null) return fallback;
        if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
            throw new IllegalArgumentException("Json repeat field '" + field + "' must be an integer");
        }
        try {
            return element.getAsBigDecimal().intValueExact();
        } catch (ArithmeticException | NumberFormatException exception) {
            throw new IllegalArgumentException("Json repeat field '" + field + "' must be an integer", exception);
        }
    }

    private static Map<Character, StructurePredicate> parsePredicates(JsonElement predicatesElement) {
        if (predicatesElement == null || predicatesElement.isJsonNull()) {
            return Map.of();
        }
        if (!predicatesElement.isJsonObject()) {
            throw new IllegalArgumentException("Json structure definition must define 'predicates' as an object");
        }
        Map<Character, StructurePredicate> predicates = new LinkedHashMap<>();
        JsonObject predicatesObject = predicatesElement.getAsJsonObject();
        for (String key : predicatesObject.keySet()) {
            if (key.length() != 1) {
                throw new IllegalArgumentException("Json predicate symbol must be exactly one character: " + key);
            }
            JsonElement predicateElement = predicatesObject.get(key);
            if (!predicateElement.isJsonObject()) {
                throw new IllegalArgumentException("Json predicate for symbol '" + key + "' must be an object");
            }
            predicates.put(key.charAt(0), StructurePredicateTypes.decode(predicateElement.getAsJsonObject()));
        }
        return Map.copyOf(predicates);
    }

    private static void validateAisles(List<String[]> slices) {
        if (slices.isEmpty()) {
            throw new IllegalArgumentException("Json structure must contain at least one slice");
        }
        int height = slices.getFirst().length;
        int width = slices.getFirst()[0].length();
        if (width == 0) {
            throw new IllegalArgumentException("Json structure rows cannot be empty");
        }
        for (int sliceIndex = 0; sliceIndex < slices.size(); sliceIndex++) {
            String[] slice = slices.get(sliceIndex);
            if (slice.length != height) {
                throw new IllegalArgumentException("Json slice " + sliceIndex + " has height " + slice.length +
                        ", expected " + height);
            }
            for (int row = 0; row < slice.length; row++) {
                if (slice[row].length() != width) {
                    throw new IllegalArgumentException("Json slice " + sliceIndex + ", row " + row + " has width " +
                            slice[row].length() + ", expected " + width);
                }
            }
        }
    }

    public record Unit(List<String[]> slices, int minRepeat, int maxRepeat) {

        public Unit {
            slices = List.copyOf(slices);
        }
    }

    public record StringArrayDefinition(List<Unit> units, Map<Character, StructurePredicate> predicates) {

        public StringArrayDefinition {
            units = List.copyOf(units);
            predicates = Map.copyOf(predicates);
        }

        public List<String[]> aisles() {
            return units.stream().flatMap(unit -> unit.slices().stream()).toList();
        }

        public BlockPattern toPattern() {
            FactoryBlockPattern builder = FactoryBlockPattern.start();
            for (Unit unit : units) {
                if (unit.minRepeat() != 1 || unit.maxRepeat() != 1 || unit.slices().size() > 1) {
                    builder.beginRepeatable();
                    unit.slices().forEach(builder::aisle);
                    builder.endRepeatable(unit.minRepeat(), unit.maxRepeat());
                } else {
                    builder.aisle(unit.slices().getFirst());
                }
            }
            for (Map.Entry<Character, StructurePredicate> entry : predicates.entrySet()) {
                builder.where(entry.getKey(), new TraceabilityPredicate(entry.getValue()));
            }
            return builder.build();
        }
    }
}
