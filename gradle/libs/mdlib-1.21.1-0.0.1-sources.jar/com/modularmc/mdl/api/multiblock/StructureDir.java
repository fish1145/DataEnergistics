package com.modularmc.mdl.api.multiblock;

import com.modularmc.mdl.api.multiblock.util.RelativeDirection;

/**
 * Defines which relative directions are used by pattern characters, rows, and aisles.
 */
public record StructureDir(RelativeDirection charDir, RelativeDirection stringDir, RelativeDirection aisleDir) {

    public StructureDir {
        if (charDir == null || stringDir == null || aisleDir == null) {
            throw new NullPointerException("Structure directions cannot be null");
        }
        if (charDir.isSameAxis(stringDir) || charDir.isSameAxis(aisleDir) || stringDir.isSameAxis(aisleDir)) {
            throw new IllegalArgumentException("Structure directions must point along three distinct axes");
        }
    }

    public static StructureDir defaultDirs() {
        return new StructureDir(RelativeDirection.LEFT, RelativeDirection.UP, RelativeDirection.FRONT);
    }
}
