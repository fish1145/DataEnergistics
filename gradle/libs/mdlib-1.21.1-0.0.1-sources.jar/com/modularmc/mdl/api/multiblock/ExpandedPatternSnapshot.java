package com.modularmc.mdl.api.multiblock;

import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Objects;

/**
 * Structurally immutable result of expanding one pattern repeat selection. Cell predicate references remain shared
 * with the source pattern definition.
 *
 * @param selection validated repeat selection
 * @param layers    expanded layers in source order
 * @param cells     flattened immutable cells
 * @param bounds    inclusive relative bounds
 */
public record ExpandedPatternSnapshot(PatternRepeatSelection selection, List<PatternLayerSnapshot> layers,
                                      List<PatternCellSnapshot> cells, PatternBounds bounds) {

    public ExpandedPatternSnapshot {
        selection = Objects.requireNonNull(selection, "selection");
        layers = List.copyOf(layers);
        cells = List.copyOf(cells);
        bounds = Objects.requireNonNull(bounds, "bounds");
        if (layers.isEmpty() || cells.isEmpty()) {
            throw new IllegalArgumentException("Expanded pattern must contain layers and cells");
        }
        validateContents(selection, layers, cells, bounds);
    }

    private static void validateContents(PatternRepeatSelection selection, List<PatternLayerSnapshot> layers,
                                         List<PatternCellSnapshot> cells, PatternBounds bounds) {
        validateLayerSources(selection, layers);
        int cellIndex = 0;
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;
        for (int layerIndex = 0; layerIndex < layers.size(); layerIndex++) {
            PatternLayerSnapshot layer = layers.get(layerIndex);
            if (layer.index() != layerIndex) {
                throw new IllegalArgumentException("Expanded pattern layer indexes must be contiguous from zero");
            }
            for (PatternCellSnapshot cell : layer.cells()) {
                if (cellIndex >= cells.size() || !cell.equals(cells.get(cellIndex))) {
                    throw new IllegalArgumentException("Flattened cells must match the layer cell order");
                }
                BlockPos position = cell.relativePosition();
                minX = Math.min(minX, position.getX());
                minY = Math.min(minY, position.getY());
                minZ = Math.min(minZ, position.getZ());
                maxX = Math.max(maxX, position.getX());
                maxY = Math.max(maxY, position.getY());
                maxZ = Math.max(maxZ, position.getZ());
                cellIndex++;
            }
        }
        if (cellIndex != cells.size()) {
            throw new IllegalArgumentException("Flattened cells must contain every layer cell exactly once");
        }
        PatternBounds actualBounds = new PatternBounds(new BlockPos(minX, minY, minZ),
                new BlockPos(maxX, maxY, maxZ));
        if (!actualBounds.equals(bounds)) {
            throw new IllegalArgumentException("Pattern bounds must exactly cover every expanded cell");
        }
    }

    private static void validateLayerSources(PatternRepeatSelection selection, List<PatternLayerSnapshot> layers) {
        int layerIndex = 0;
        int sourceStart = 0;
        for (int unitIndex = 0; unitIndex < selection.counts().size(); unitIndex++) {
            int depth = firstRepeatDepth(layers, layerIndex, unitIndex, sourceStart);
            for (int repeatIndex = 0; repeatIndex < selection.count(unitIndex); repeatIndex++) {
                for (int innerLayer = 0; innerLayer < depth; innerLayer++) {
                    if (layerIndex >= layers.size()) {
                        throw new IllegalArgumentException("Expanded pattern is missing selected repetitions");
                    }
                    PatternLayerSource source = layers.get(layerIndex).source();
                    if (source.unitIndex() != unitIndex || source.repeatIndex() != repeatIndex ||
                            source.innerLayer() != innerLayer || source.sourceLayer() != sourceStart + innerLayer) {
                        throw new IllegalArgumentException(
                                "Expanded layer sources must follow the complete repeat selection in source order");
                    }
                    layerIndex++;
                }
            }
            sourceStart = Math.addExact(sourceStart, depth);
        }
        if (layerIndex != layers.size()) {
            throw new IllegalArgumentException("Expanded pattern contains layers outside the repeat selection");
        }
    }

    private static int firstRepeatDepth(List<PatternLayerSnapshot> layers, int startIndex, int unitIndex,
                                        int sourceStart) {
        int depth = 0;
        while (startIndex + depth < layers.size()) {
            PatternLayerSource source = layers.get(startIndex + depth).source();
            if (source.unitIndex() != unitIndex || source.repeatIndex() != 0) {
                break;
            }
            if (source.innerLayer() != depth || source.sourceLayer() != sourceStart + depth) {
                throw new IllegalArgumentException("The first repetition must follow contiguous source layer order");
            }
            depth++;
        }
        if (depth == 0) {
            throw new IllegalArgumentException("Expanded pattern is missing a selected unit");
        }
        return depth;
    }
}
