package com.modularmc.mdl;

import com.modularmc.mdl.api.MDLValues;
import com.modularmc.mdl.utils.FormattingUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLModContainer;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.data.loading.DatagenModLoader;
import net.neoforged.neoforge.server.ServerLifecycleHooks;

import com.mojang.serialization.Codec;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.ApiStatus;

import java.nio.file.Path;

@Mod(MDLib.MOD_ID)
public class MDLib {

    public static final String MOD_ID = "mdlib";
    private static final ResourceLocation TEMPLATE_LOCATION = ResourceLocation.parse(MOD_ID + ":");
    public static final Codec<ResourceLocation> MDLib_ID = Codec.STRING.comapFlatMap(
            str -> ResourceLocation.read(appendIdString(str)),
            s -> s.getNamespace().equals(MOD_ID) ? s.getPath() : s.toString());

    public static final String MOD_NAME = "Modular Data lib";
    public static final Logger LOGGER = LogManager.getLogger(MOD_NAME);
    @ApiStatus.Internal
    public static IEventBus gtModBus;

    public MDLib(IEventBus modBus, FMLModContainer container) {
        // StructurePredicateType.init();
        // StructureCache.loadAsync();
        // GTCEuAPI.instance = this;
        MDLib.gtModBus = modBus;
        // ConfigHolder.init();

        // GTCEuAPI.initializeHighTier();
        if (MDLib.isDev()) {
            // ConfigHolder.INSTANCE.recipes.generateLowQualityGems = true;
            // ConfigHolder.INSTANCE.compat.energy.enableFEConverters = true;
        }
        // CommonProxy.init(modBus);

        // modBus.addListener(GTNetwork::registerPayloads);
    }

    public static ResourceLocation id(String path) {
        if (path.isBlank()) {
            return TEMPLATE_LOCATION;
        }

        int i = path.indexOf(':');
        if (i > 0) {
            return ResourceLocation.tryParse(path);
        } else if (i == 0) {
            path = path.substring(i + 1);
        }
        // only convert it to camel_case if it has any uppercase to begin with
        if (FormattingUtil.hasUpperCase(path)) {
            path = FormattingUtil.toLowerCaseUnderscore(path);
        }
        return TEMPLATE_LOCATION.withPath(path);
    }

    public static String appendIdString(String id) {
        int i = id.indexOf(':');
        if (i > 0) {
            return id;
        } else if (i == 0) {
            return MOD_ID + id;
        } else {
            return MOD_ID + ":" + id;
        }
    }

    /**
     * @return if we're running in a production environment
     */
    public static boolean isProd() {
        return FMLLoader.isProduction();
    }

    /**
     * @return if we're not running in a production environment
     */
    public static boolean isDev() {
        return !isProd();
    }

    /**
     * @return if we're running data generation
     */
    public static boolean isDataGen() {
        return DatagenModLoader.isRunningDataGen();
    }

    /**
     * A friendly reminder that the server instance is populated on the server side only, so null/side check it!
     *
     * @return the current minecraft server instance
     */
    public static MinecraftServer getMinecraftServer() {
        return ServerLifecycleHooks.getCurrentServer();
    }

    /**
     * @param modId the mod id to check for
     * @return if the mod whose id is {@code modId} is loaded or not
     */
    public static boolean isModLoaded(String modId) {
        ModList modList = ModList.get();
        if (modList != null) return modList.isLoaded(modId);
        else return FMLLoader.getLoadingModList().getModFileById(modId) != null;
    }

    /**
     * For async stuff use this, otherwise use {@link MDLValues isClientSide}
     *
     * @return if the current thread is the client thread
     */
    @SuppressWarnings("ConstantValue")
    public static boolean isClientThread() {
        return isClientSide() && Minecraft.getInstance() != null && Minecraft.getInstance().isSameThread();
    }

    /**
     * @return if the game is the <strong>PHYSICAL</strong> client, e.g. not a dedicated server.
     * @apiNote Do not use this to check if you're currently on the server thread for side-specific actions!
     *          It does <strong>NOT</strong> work for that. Use {@link #isClientThread()} instead.
     * @see #isClientThread()
     */
    public static boolean isClientSide() {
        return FMLEnvironment.dist.isClient();
    }

    /**
     * This check isn't the same for client and server!
     *
     * @return if it's safe to access the current instance {@link Level} on client or if
     *         it's safe to access any level on server.
     */
    public static boolean canGetServerLevel() {
        if (isClientSide()) {
            return Minecraft.getInstance().level != null;
        }
        var server = getMinecraftServer();
        return server != null &&
                !(server.isStopped() || server.isShutdown() || !server.isRunning() || server.isCurrentlySaving());
    }

    /**
     * @return the path to the minecraft instance directory
     */
    public static Path getGameDir() {
        return FMLPaths.GAMEDIR.get();
    }

    /**
     * Resolves the library data directory only after the NeoForge game path is initialized.
     *
     * @return the mdlib directory inside the active game directory
     */
    public static Path getMdlibFolder() {
        return getGameDir().resolve("mdlib");
    }

    public static class Mods {

        public static boolean isAnyRecipeViewerLoaded() {
            return isModLoaded(MDLValues.MODID_EMI) || isModLoaded(MDLValues.MODID_JEI);
        }

        public static boolean isJEILoaded() {
            return !isModLoaded(MDLValues.MODID_EMI) && isModLoaded(MDLValues.MODID_JEI);
        }

        public static boolean isEMILoaded() {
            return isModLoaded(MDLValues.MODID_EMI);
        }

        public static boolean isKubeJSLoaded() {
            return isModLoaded(MDLValues.MODID_KUBEJS);
        }

        public static boolean isIrisLoaded() {
            return isModLoaded(MDLValues.MODID_IRIS);
        }

        public static boolean isSodiumLoaded() {
            return isModLoaded(MDLValues.MODID_SODIUM);
        }

        public static boolean isAE2Loaded() {
            return isModLoaded(MDLValues.MODID_APPENG);
        }

        public static boolean isCuriosLoaded() {
            return isModLoaded(MDLValues.MODID_CURIOS);
        }

        public static boolean isModernFixLoaded() {
            return isModLoaded(MDLValues.MODID_MODERNFIX);
        }

        public static boolean isFTBTeamsLoaded() {
            return isModLoaded(MDLValues.MODID_FTB_TEAMS);
        }

        public static boolean isHeraclesLoaded() {
            return isModLoaded(MDLValues.MODID_HERACLES);
        }

        public static boolean isFTBQuestsLoaded() {
            return isModLoaded(MDLValues.MODID_FTB_QUEST);
        }

        public static boolean isArgonautsLoaded() {
            return isModLoaded(MDLValues.MODID_ARGONAUTS);
        }

        public static boolean isGameStagesLoaded() {
            return isModLoaded(MDLValues.MODID_GAMESTAGES);
        }

        public static boolean isCCTweakedLoaded() {
            return isModLoaded(MDLValues.MODID_CCTWEAKED);
        }

        public static boolean isCreateLoaded() {
            return isModLoaded(MDLValues.MODID_CREATE);
        }
    }
}
